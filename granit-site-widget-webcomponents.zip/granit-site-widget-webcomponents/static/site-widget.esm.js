import {
  applyOptionsToElement,
  normalizeWidgetConfig,
  parseMobileActions,
  parseQuickReplies,
} from '../shared/site-widget-domain.js';
import {
  GranitSiteWidgetElement,
  SITE_WIDGET_TAG_NAME,
  defineSiteWidgetElement,
} from './components/granit-site-widget.js';

const defineSiteWidget = (tagName = SITE_WIDGET_TAG_NAME) => {
  defineSiteWidgetElement(tagName);
};

const mountSiteWidget = (options = {}) => {
  if (typeof document === 'undefined') {
    throw new Error('mountSiteWidget requires a browser document');
  }

  defineSiteWidget();
  const element = document.createElement(SITE_WIDGET_TAG_NAME);
  applyOptionsToElement(element, options);

  const target = options.target || document.body;
  if (!target) throw new Error('mountSiteWidget target was not found');
  target.append(element);
  return element;
};

if (typeof window !== 'undefined') {
  window.GranitSiteWidget = {
    define: defineSiteWidget,
    mount: mountSiteWidget,
    tagName: SITE_WIDGET_TAG_NAME,
  };
  defineSiteWidget();
}

export {
  GranitSiteWidgetElement,
  SITE_WIDGET_TAG_NAME,
  defineSiteWidget,
  mountSiteWidget,
  normalizeWidgetConfig,
  parseMobileActions,
  parseQuickReplies,
};
