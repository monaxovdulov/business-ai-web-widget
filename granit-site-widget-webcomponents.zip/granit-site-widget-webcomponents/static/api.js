import { mapSiteWidgetResponse } from '../shared/site-widget-domain.js';

const JSON_HEADERS = Object.freeze({
  Accept: 'application/json',
  'Content-Type': 'application/json',
});

const sendSiteWidgetMessage = async (config, request, signal) => {
  if (config.mock) return mockSiteWidgetMessage(config, request);
  if (!config.apiBaseUrl) {
    throw new Error('api-base-url is required when mock=false');
  }

  const response = await fetch(`${config.apiBaseUrl}/public/intake/site-widget/messages`, {
    method: 'POST',
    headers: JSON_HEADERS,
    body: JSON.stringify(request),
    credentials: 'omit',
    signal,
  });

  const body = await readResponseBody(response);
  if (!response.ok) {
    const message = readErrorMessage(body) || `Widget request failed with HTTP ${response.status}`;
    throw new Error(message);
  }

  return mapSiteWidgetResponse(body, config);
};

const mockSiteWidgetMessage = async (config, request) => {
  await delay(350);

  const text = String(request?.message?.text || '').toLowerCase();
  if (text.includes('менеджер') || text.includes('позвон')) {
    return {
      status: 'fallback',
      publicSessionId: request.public_session_id,
      replyText: '',
      systemText: 'Передали менеджеру. Он свяжется с вами по указанным контактам или ответит здесь.',
      reason: 'manager_requested',
      raw: { mock: true },
    };
  }

  if (
    text.includes('сто') ||
    text.includes('цен') ||
    text.includes('расчет') ||
    text.includes('расчёт')
  ) {
    return {
      status: 'replied',
      publicSessionId: request.public_session_id,
      replyText:
        'Стоимость зависит от модели, размера и комплектации. Опишите, пожалуйста, какой памятник нужен, или приложите фото — подготовим расчет.',
      systemText: '',
      reason: '',
      raw: { mock: true },
    };
  }

  return {
    status: 'replied',
    publicSessionId: request.public_session_id,
    replyText:
      'Приняли сообщение. Уточните, пожалуйста, город, примерный размер и нужен ли монтаж — так менеджер быстрее подготовит ответ.',
    systemText: '',
    reason: '',
    raw: { mock: true },
  };
};

const readResponseBody = async (response) => {
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) return response.json().catch(() => null);
  const text = await response.text().catch(() => '');
  return text ? { message: text } : null;
};

const readErrorMessage = (body) => {
  if (!body || typeof body !== 'object') return '';
  if (typeof body.message === 'string') return body.message;
  if (typeof body.error === 'string') return body.error;
  return '';
};

const delay = (ms) => new Promise((resolve) => globalThis.setTimeout(resolve, ms));

export { mockSiteWidgetMessage, sendSiteWidgetMessage };
