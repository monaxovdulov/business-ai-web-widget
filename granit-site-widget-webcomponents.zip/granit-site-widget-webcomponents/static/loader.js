(function loadGranitSiteWidget() {
  const script = document.currentScript || document.querySelector('script[data-granit-site-widget-loader]');
  if (!script) return;

  const moduleUrl = new URL('./site-widget.esm.js', script.src).href;
  const targetSelector = script.dataset.target || '';
  const options = readOptions(script);

  import(moduleUrl)
    .then((module) => {
      const target = targetSelector ? document.querySelector(targetSelector) : document.body;
      module.mountSiteWidget({ ...options, target });
    })
    .catch((error) => {
      setTimeout(() => {
        throw error;
      }, 0);
    });
})();

function readOptions(script) {
  const data = script.dataset;
  const options = {
    apiBaseUrl: data.apiBaseUrl || '',
    widgetInstanceId: data.widgetInstanceId || 'default',
    theme: data.theme || 'memorial-soft',
    position: data.position || 'bottom-right',
    mock: parseBoolean(data.mock),
    open: parseBoolean(data.open),
    launcherLabel: data.launcherLabel,
    headerTitle: data.headerTitle,
    headerStatus: data.headerStatus,
    headerResponseTime: data.headerResponseTime,
    introMessage: data.introMessage,
    placeholder: data.placeholder,
    disclosureText: data.disclosureText,
    footerNote: data.footerNote,
    phoneCaptureLabel: data.phoneCaptureLabel,
    phoneSavedLabel: data.phoneSavedLabel,
    fallbackMessage: data.fallbackMessage,
    disabledMessage: data.disabledMessage,
    errorMessage: data.errorMessage,
    retryLabel: data.retryLabel,
    sendLabel: data.sendLabel,
    attachLabel: data.attachLabel,
    closeLabel: data.closeLabel,
    minimizeLabel: data.minimizeLabel,
    phoneHref: data.phoneHref,
    privacyUrl: data.privacyUrl,
  };

  if (data.quickReplies) options.quickReplies = parseList(data.quickReplies);
  if (data.mobileActions) options.mobileActions = parseList(data.mobileActions);

  for (const key of Object.keys(options)) {
    if (options[key] === undefined) delete options[key];
  }

  return options;
}

function parseBoolean(value) {
  if (value === undefined) return false;
  const normalized = String(value).trim().toLowerCase();
  return normalized === '' || normalized === '1' || normalized === 'true' || normalized === 'yes';
}

function parseList(value) {
  const trimmed = String(value || '').trim();
  if (!trimmed) return [];
  try {
    return JSON.parse(trimmed);
  } catch {
    return trimmed.split('|').map((label) => ({ label: label.trim(), value: label.trim() })).filter((item) => item.label);
  }
}
