import {
  OBSERVED_ATTRIBUTES,
  applyWidgetAction,
  buildSiteWidgetMessageRequest,
  buildWidgetViewModel,
  createIdempotencyKey,
  createWidgetState,
  normalizeWidgetConfig,
  readConfigFromElement,
  validateDraft,
} from '../../shared/site-widget-domain.js';
import { sendSiteWidgetMessage } from '../api.js';
import { readBrowserEnvironment } from '../browser-env.js';
import { emitWidgetEvent } from '../events.js';
import { createSessionStore } from '../session-store.js';
import { cloneTemplate } from './template-registry.js';
import { setIcon } from './icons.js';
import { WIDGET_MESSAGE_TAG_NAME, defineWidgetMessage } from './widget-message.js';

const SITE_WIDGET_TAG_NAME = 'granit-site-widget';
const HTMLElementBase = typeof HTMLElement === 'undefined' ? class {} : HTMLElement;

class GranitSiteWidgetElement extends HTMLElementBase {
  static get observedAttributes() {
    return OBSERVED_ATTRIBUTES;
  }

  constructor() {
    super();
    this.config = normalizeWidgetConfig();
    this.state = createWidgetState({ config: this.config });
    this.initialized = false;
    this.listenersBound = false;
    this.abortController = null;
    this.publicSessionId = '';
    this.sessionStore = null;

    if (typeof this.attachShadow === 'function') {
      this.attachShadow({ mode: 'open' });
      const content = cloneTemplate(SITE_WIDGET_TAG_NAME);
      this.refs = collectRefs(content);
      this.shadowRoot.append(content);
      this.installStaticIcons();
    }
  }

  connectedCallback() {
    this.boot();
  }

  disconnectedCallback() {
    this.abortController?.abort();
  }

  attributeChangedCallback(name) {
    if (!this.initialized) return;
    if (name === 'open') {
      this.state = applyWidgetAction(this.state, {
        type: this.hasAttribute('open') ? 'open' : 'close',
      });
    }
    this.config = readConfigFromElement(this);
    this.syncHostAttributes();
    this.render();
  }

  open() {
    this.boot();
    this.state = applyWidgetAction(this.state, { type: 'open' });
    this.setAttribute('open', '');
    emitWidgetEvent(this, 'open', { widgetInstanceId: this.config.widgetInstanceId });
    this.render();
    this.focusInputSoon();
  }

  close() {
    this.boot();
    this.state = applyWidgetAction(this.state, { type: 'close' });
    this.removeAttribute('open');
    emitWidgetEvent(this, 'close', { widgetInstanceId: this.config.widgetInstanceId });
    this.render();
  }

  sendMessage(text) {
    this.boot();
    const normalized = String(text || '').trim();
    if (!normalized) return;
    this.state = applyWidgetAction(this.state, {
      type: 'draft.changed',
      value: normalized,
    });
    void this.submitDraft();
  }

  clearSession() {
    this.sessionStore?.clear();
    this.publicSessionId = this.sessionStore?.get() || '';
  }

  boot() {
    if (this.initialized) return;
    defineWidgetMessage();
    this.config = readConfigFromElement(this);
    this.syncHostAttributes();
    this.state = createWidgetState({
      config: this.config,
      open: this.hasAttribute('open'),
    });
    this.sessionStore = createSessionStore(this.config.widgetInstanceId);
    this.publicSessionId = this.sessionStore.get();
    this.bindEvents();
    this.initialized = true;
    this.render();
    emitWidgetEvent(this, 'ready', { widgetInstanceId: this.config.widgetInstanceId });
  }

  bindEvents() {
    if (!this.shadowRoot || this.listenersBound) return;
    this.listenersBound = true;

    this.refs.launcher.addEventListener('click', () => this.open());
    this.refs.minimizeButton.addEventListener('click', () => this.close());
    this.refs.closeButton.addEventListener('click', () => this.close());

    this.refs.form.addEventListener('submit', (event) => {
      event.preventDefault();
      void this.submitDraft();
    });

    this.refs.messageInput.addEventListener('input', () => {
      this.state = applyWidgetAction(this.state, {
        type: 'draft.changed',
        value: this.refs.messageInput.value,
      });
      this.autoGrowTextarea();
      this.updateComposerState();
    });

    this.refs.messageInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        void this.submitDraft();
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        this.close();
      }
    });

    this.refs.quickReplies.addEventListener('click', (event) => {
      const button = event.target.closest?.('[data-action="quick-reply"]');
      if (!button) return;
      this.state = applyWidgetAction(this.state, {
        type: 'draft.changed',
        value: button.dataset.value || button.textContent || '',
      });
      void this.submitDraft();
    });

    this.refs.mobileActions.addEventListener('click', (event) => {
      const button = event.target.closest?.('[data-action="mobile-action"]');
      if (!button) return;
      this.handleMobileAction(button.dataset.mobileAction || '', button.dataset.value || '');
    });

    this.refs.contactTrigger.addEventListener('click', () => {
      this.state = applyWidgetAction(this.state, {
        type: 'contact.capture.toggled',
      });
      this.render();
      if (this.state.contactCaptureOpen) this.refs.phoneInput.focus();
    });

    this.refs.phoneSaveButton.addEventListener('click', () => this.savePhone());
    this.refs.phoneInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        this.savePhone();
      }
    });

    this.refs.retryButton.addEventListener('click', () => {
      void this.retryPending();
    });
  }

  installStaticIcons() {
    if (!this.refs) return;
    setIcon(this.refs.launcherIcon, 'message');
    setIcon(this.refs.brandIcon, 'brand');
    setIcon(this.refs.minimizeButton, 'minus');
    setIcon(this.refs.closeButton, 'close');
    setIcon(this.refs.attachButton, 'paperclip');
    setIcon(this.refs.shieldIcon, 'shield');
  }

  syncHostAttributes() {
    if (this.getAttribute('theme') !== this.config.theme) {
      this.setAttribute('theme', this.config.theme);
    }
    if (this.getAttribute('position') !== this.config.position) {
      this.setAttribute('position', this.config.position);
    }
  }

  render() {
    if (!this.shadowRoot) return;
    const view = buildWidgetViewModel(this.state, this.config);

    this.refs.launcher.hidden = view.open;
    this.refs.panel.hidden = !view.open;
    this.refs.mobileActions.hidden = view.open || this.config.mobileActions.length === 0;
    this.refs.launcher.setAttribute('aria-expanded', String(view.open));

    this.refs.launcherLabel.textContent = this.config.launcherLabel;
    this.refs.title.textContent = this.config.headerTitle;
    this.refs.statusText.textContent = this.config.headerStatus;
    this.refs.responseTime.textContent = this.config.headerResponseTime;
    this.refs.inputLabel.textContent = this.config.placeholder;
    this.refs.messageInput.placeholder = this.config.placeholder;
    this.refs.footerNote.textContent = this.config.footerNote;
    this.refs.contactLabel.textContent = view.contactLabel;
    this.refs.retryButton.textContent = this.config.retryLabel;
    this.refs.minimizeButton.setAttribute('aria-label', this.config.minimizeLabel);
    this.refs.closeButton.setAttribute('aria-label', this.config.closeLabel);
    this.refs.attachButton.setAttribute('aria-label', this.config.attachLabel);
    this.refs.sendButton.setAttribute('aria-label', this.config.sendLabel);

    this.renderMessages(view.messages);
    this.renderQuickReplies(view);
    this.renderMobileActions();

    this.refs.messageInput.disabled = view.submitting;
    this.refs.messageInput.value = view.draft;
    this.refs.retryButton.hidden = !view.pending || view.submitting;
    this.refs.contactCapture.hidden = !view.contactCaptureOpen;
    this.refs.phoneInput.value = view.contactPhone;
    this.updateComposerState();
    this.autoGrowTextarea();
    this.scrollLogToBottom();
  }

  renderMessages(messages) {
    const nodes = messages.map((message) => {
      const node = document.createElement(WIDGET_MESSAGE_TAG_NAME);
      node.setAttribute('role', message.role);
      node.setAttribute('text', message.text);
      node.setAttribute('status', message.status || 'sent');
      node.setAttribute('disclosure-text', this.config.disclosureText);
      node.setAttribute('part', `message message-${message.role}`);
      if (message.disclosure) node.setAttribute('disclosure', '');
      return node;
    });
    this.refs.log.replaceChildren(...nodes);
  }

  renderQuickReplies(view) {
    if (!view.showQuickReplies) {
      this.refs.quickReplies.replaceChildren();
      return;
    }

    const buttons = this.config.quickReplies.map((reply) => {
      const button = document.createElement('button');
      button.className = 'quick-reply';
      button.setAttribute('part', 'quick-reply');
      button.type = 'button';
      button.dataset.action = 'quick-reply';
      button.dataset.value = reply.value || reply.label;
      button.textContent = reply.label;
      return button;
    });

    this.refs.quickReplies.replaceChildren(...buttons);
  }

  renderMobileActions() {
    if (this.config.mobileActions.length === 0) {
      this.refs.mobileActions.replaceChildren();
      return;
    }

    const nodes = this.config.mobileActions.map((action) => {
      const isCall = action.id === 'call';
      const href = action.href || this.config.phoneHref;
      const node = isCall && href ? document.createElement('a') : document.createElement('button');

      node.className = 'mobile-action';
      node.setAttribute('part', `mobile-action mobile-action-${action.id}`);
      if (node instanceof HTMLAnchorElement) {
        node.href = href;
      } else {
        node.type = 'button';
        node.dataset.action = 'mobile-action';
        node.dataset.mobileAction = action.id;
        node.dataset.value = action.value || '';
      }

      const icon = document.createElement('span');
      icon.className = 'mobile-icon';
      icon.setAttribute('aria-hidden', 'true');
      setIcon(icon, action.icon || action.id);

      const label = document.createElement('span');
      label.textContent = action.label;

      node.replaceChildren(icon, label);
      return node;
    });

    this.refs.mobileActions.replaceChildren(...nodes);
  }

  updateComposerState() {
    const view = buildWidgetViewModel(this.state, this.config);
    this.refs.sendButton.disabled = !view.canSend;
    setIcon(this.refs.sendButton, view.submitting ? 'loader' : 'send');
  }

  handleMobileAction(id, value) {
    if (id === 'message') {
      this.open();
      return;
    }

    if (id === 'calculation') {
      this.open();
      this.state = applyWidgetAction(this.state, {
        type: 'draft.changed',
        value: value || 'Нужен расчет памятника',
      });
      this.render();
      this.focusInputSoon();
      return;
    }

    this.open();
  }

  savePhone() {
    const phone = this.refs.phoneInput.value.trim();
    this.state = applyWidgetAction(this.state, {
      type: 'contact.phone.saved',
      phone,
    });
    emitWidgetEvent(this, 'phone-saved', {
      widgetInstanceId: this.config.widgetInstanceId,
      hasPhone: phone.length > 0,
    });
    this.render();
  }

  async submitDraft() {
    const text = this.state.draft.trim();
    const draftError = validateDraft(text, this.config);
    if (draftError || this.state.submitting) return;

    const idempotencyKey = createIdempotencyKey(this.publicSessionId);
    this.state = applyWidgetAction(this.state, {
      type: 'submit.started',
      text,
      idempotencyKey,
    });
    this.render();
    await this.sendPending(text, idempotencyKey);
  }

  async retryPending() {
    if (!this.state.pending) return;
    const { text, idempotencyKey } = this.state.pending;
    this.state = applyWidgetAction(this.state, { type: 'retry.started' });
    this.render();
    await this.sendPending(text, idempotencyKey);
  }

  async sendPending(text, idempotencyKey) {
    this.abortController?.abort();
    this.abortController = new AbortController();

    try {
      const request = buildSiteWidgetMessageRequest({
        config: this.config,
        text,
        publicSessionId: this.publicSessionId,
        idempotencyKey,
        contact: this.buildContact(),
        environment: readBrowserEnvironment(),
      });

      emitWidgetEvent(this, 'message-submitted', {
        widgetInstanceId: this.config.widgetInstanceId,
        idempotencyKey,
        publicSessionId: this.publicSessionId,
      });

      const response = await sendSiteWidgetMessage(
        this.config,
        request,
        this.abortController.signal,
      );

      if (response.publicSessionId) {
        this.publicSessionId = response.publicSessionId;
        this.sessionStore?.set(response.publicSessionId);
      }

      this.state = applyWidgetAction(this.state, {
        type: 'visitor.persisted',
        text,
      });

      if (response.status === 'replied' && response.replyText) {
        this.state = applyWidgetAction(this.state, {
          type: 'assistant.replied',
          text: response.replyText,
        });
      } else {
        this.state = applyWidgetAction(this.state, {
          type: 'system.message',
          text: response.systemText || this.config.fallbackMessage,
        });
      }

      emitWidgetEvent(this, 'response', {
        widgetInstanceId: this.config.widgetInstanceId,
        status: response.status,
        reason: response.reason || '',
      });
      this.render();
    } catch (error) {
      if (error?.name === 'AbortError') return;
      this.state = applyWidgetAction(this.state, {
        type: 'submit.failed',
        text: this.config.errorMessage,
      });
      emitWidgetEvent(this, 'error', {
        widgetInstanceId: this.config.widgetInstanceId,
        message: error instanceof Error ? error.message : String(error),
      });
      this.render();
    }
  }

  buildContact() {
    const phone = this.state.contactPhone.trim();
    if (!phone) return undefined;
    return { phone, preferred_contact: 'phone' };
  }

  autoGrowTextarea() {
    const input = this.refs.messageInput;
    input.style.height = 'auto';
    input.style.height = `${Math.min(input.scrollHeight, 118)}px`;
  }

  scrollLogToBottom() {
    this.refs.log.scrollTop = this.refs.log.scrollHeight;
  }

  focusInputSoon() {
    window.setTimeout(() => this.refs.messageInput.focus(), 0);
  }
}

const collectRefs = (root) => {
  const get = (id) => {
    const node = root.getElementById(id);
    if (!node) throw new Error(`Missing widget template node: ${id}`);
    return node;
  };

  return {
    root: get('root'),
    launcher: get('launcher'),
    launcherIcon: get('launcherIcon'),
    launcherLabel: get('launcherLabel'),
    mobileActions: get('mobileActions'),
    panel: get('panel'),
    brandIcon: get('brandIcon'),
    title: get('title'),
    statusText: get('statusText'),
    responseTime: get('responseTime'),
    minimizeButton: get('minimizeButton'),
    closeButton: get('closeButton'),
    log: get('log'),
    quickReplies: get('quickReplies'),
    form: get('form'),
    attachButton: get('attachButton'),
    inputLabel: get('inputLabel'),
    messageInput: get('messageInput'),
    sendButton: get('sendButton'),
    retryButton: get('retryButton'),
    contactTrigger: get('contactTrigger'),
    contactLabel: get('contactLabel'),
    contactCapture: get('contactCapture'),
    phoneInput: get('phoneInput'),
    phoneSaveButton: get('phoneSaveButton'),
    shieldIcon: get('shieldIcon'),
    footerNote: get('footerNote'),
  };
};

const defineSiteWidgetElement = (tagName = SITE_WIDGET_TAG_NAME) => {
  if (typeof customElements === 'undefined') return;
  defineWidgetMessage();
  if (!customElements.get(tagName)) customElements.define(tagName, GranitSiteWidgetElement);
};

export {
  GranitSiteWidgetElement,
  SITE_WIDGET_TAG_NAME,
  defineSiteWidgetElement,
};
