import { cloneTemplate } from './template-registry.js';
import { setIcon } from './icons.js';

const TAG_NAME = 'granit-widget-message';
const HTMLElementBase = typeof HTMLElement === 'undefined' ? class {} : HTMLElement;

class GranitWidgetMessageElement extends HTMLElementBase {
  static get observedAttributes() {
    return ['role', 'text', 'status', 'disclosure', 'disclosure-text'];
  }

  constructor() {
    super();
    if (typeof this.attachShadow === 'function') {
      this.attachShadow({ mode: 'open' });
      const content = cloneTemplate(TAG_NAME);
      this.textEl = content.getElementById('text');
      this.disclosureEl = content.getElementById('disclosure');
      this.disclosureTextEl = content.getElementById('disclosureText');
      this.statusTextEl = content.getElementById('statusText');
      this.sparkIconEl = content.getElementById('sparkIcon');
      this.shadowRoot.append(content);
    }
  }

  connectedCallback() {
    this.render();
  }

  attributeChangedCallback() {
    this.render();
  }

  render() {
    if (!this.shadowRoot) return;
    const text = this.getAttribute('text') || '';
    const status = this.getAttribute('status') || 'sent';
    const disclosure = this.hasAttribute('disclosure');

    this.textEl.textContent = text;
    this.disclosureTextEl.textContent = this.getAttribute('disclosure-text') || '';
    this.disclosureEl.hidden = !disclosure;
    setIcon(this.sparkIconEl, 'spark');

    let statusText = '';
    if (status === 'pending') statusText = 'отправляем...';
    if (status === 'error') statusText = 'ошибка отправки';
    this.statusTextEl.textContent = statusText;
    this.statusTextEl.hidden = !statusText;
  }
}

const defineWidgetMessage = () => {
  if (typeof customElements === 'undefined') return;
  if (!customElements.get(TAG_NAME)) customElements.define(TAG_NAME, GranitWidgetMessageElement);
};

export { GranitWidgetMessageElement, TAG_NAME as WIDGET_MESSAGE_TAG_NAME, defineWidgetMessage };
