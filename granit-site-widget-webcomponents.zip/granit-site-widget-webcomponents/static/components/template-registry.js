const TEMPLATE_HTML = Object.freeze({
  'granit-site-widget': String.raw`
    <template id="granit-site-widget">
      <style>
        :host {
          --sw-color-accent: #9d8062;
          --sw-color-accent-text: #ffffff;
          --sw-color-panel: #fffaf5;
          --sw-color-surface: #ffffff;
          --sw-color-surface-muted: #f5eee7;
          --sw-color-visitor: #efe2d5;
          --sw-color-system: #f7f3ee;
          --sw-color-text: #27231f;
          --sw-color-text-muted: #756d64;
          --sw-color-border: rgba(84, 68, 52, 0.16);
          --sw-radius-panel: 28px;
          --sw-radius-bubble: 16px;
          --sw-radius-control: 999px;
          --sw-shadow-panel: 0 28px 90px rgba(35, 29, 22, 0.18);
          --sw-shadow-launcher: 0 12px 36px rgba(35, 29, 22, 0.18);
          --sw-font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          color: var(--sw-color-text);
          display: block;
          font-family: var(--sw-font-family);
          font-size: 15px;
          line-height: 1.45;
          position: fixed;
          right: 28px;
          bottom: 28px;
          z-index: 2147483000;
        }

        :host([position="bottom-left"]) {
          left: 28px;
          right: auto;
        }

        :host([position="inline"]) {
          bottom: auto;
          left: auto;
          position: relative;
          right: auto;
          z-index: auto;
        }

        :host([hidden]) { display: none; }
        *, *::before, *::after { box-sizing: border-box; }
        button, input, textarea { font: inherit; }
        button { color: inherit; }
        [hidden] { display: none !important; }

        .visually-hidden {
          border: 0;
          clip: rect(0 0 0 0);
          height: 1px;
          margin: -1px;
          overflow: hidden;
          padding: 0;
          position: absolute;
          white-space: nowrap;
          width: 1px;
        }

        .root { display: contents; }

        .launcher {
          align-items: center;
          background: var(--sw-color-accent);
          border: 0;
          border-radius: var(--sw-radius-control);
          box-shadow: var(--sw-shadow-launcher);
          color: var(--sw-color-accent-text);
          cursor: pointer;
          display: inline-flex;
          gap: 12px;
          min-height: 58px;
          padding: 0 24px;
          transition: transform 160ms ease, box-shadow 160ms ease;
        }

        .launcher:hover { transform: translateY(-1px); }
        .launcher:focus-visible,
        .icon-button:focus-visible,
        .quick-reply:focus-visible,
        .send:focus-visible,
        .mobile-action:focus-visible,
        .contact-trigger:focus-visible,
        .phone-save:focus-visible,
        .retry:focus-visible {
          outline: 3px solid rgba(157, 128, 98, 0.28);
          outline-offset: 3px;
        }

        .launcher-icon,
        .mobile-icon,
        .inline-icon,
        .send-icon,
        .attach-icon { display: inline-flex; }

        .panel {
          background: color-mix(in srgb, var(--sw-color-panel) 96%, transparent);
          border: 1px solid var(--sw-color-border);
          border-radius: var(--sw-radius-panel);
          box-shadow: var(--sw-shadow-panel);
          display: flex;
          flex-direction: column;
          max-height: min(720px, calc(100vh - 48px));
          overflow: hidden;
          width: min(640px, calc(100vw - 36px));
        }

        .header {
          align-items: center;
          border-bottom: 1px solid var(--sw-color-border);
          display: grid;
          gap: 14px;
          grid-template-columns: 48px 1fr 40px 40px;
          min-height: 96px;
          padding: 22px 22px 20px;
        }

        .brand {
          align-items: center;
          background: var(--sw-color-surface);
          border: 1px solid var(--sw-color-border);
          border-radius: 50%;
          box-shadow: 0 8px 24px rgba(35, 29, 22, 0.08);
          color: var(--sw-color-accent);
          display: inline-flex;
          height: 48px;
          justify-content: center;
          width: 48px;
        }

        .title {
          font-size: 21px;
          font-weight: 680;
          letter-spacing: -0.02em;
          margin: 0 0 4px;
        }

        .status-line {
          align-items: center;
          color: var(--sw-color-text-muted);
          display: flex;
          flex-wrap: wrap;
          font-size: 13px;
          gap: 8px;
        }

        .status-dot {
          background: #59c765;
          border-radius: 50%;
          display: inline-block;
          height: 8px;
          width: 8px;
        }

        .icon-button {
          align-items: center;
          background: var(--sw-color-surface);
          border: 1px solid var(--sw-color-border);
          border-radius: 50%;
          cursor: pointer;
          display: inline-flex;
          height: 40px;
          justify-content: center;
          padding: 0;
          width: 40px;
        }

        .body {
          display: flex;
          flex: 1;
          flex-direction: column;
          gap: 14px;
          min-height: 300px;
          overflow: hidden;
          padding: 22px;
        }

        .log {
          display: flex;
          flex: 1;
          flex-direction: column;
          gap: 12px;
          min-height: 240px;
          overflow-y: auto;
          padding-right: 4px;
          scroll-behavior: smooth;
        }

        .quick-replies {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
        }

        .quick-reply {
          background: var(--sw-color-surface);
          border: 1px solid var(--sw-color-border);
          border-radius: var(--sw-radius-control);
          cursor: pointer;
          min-height: 44px;
          padding: 0 17px;
        }

        .quick-reply:hover { border-color: var(--sw-color-accent); }

        .composer-shell {
          border-top: 1px solid var(--sw-color-border);
          padding: 18px 22px 20px;
        }

        .composer {
          align-items: center;
          background: var(--sw-color-surface);
          border: 1px solid var(--sw-color-border);
          border-radius: var(--sw-radius-control);
          display: grid;
          gap: 10px;
          grid-template-columns: 38px 1fr 44px;
          min-height: 58px;
          padding: 7px 8px 7px 12px;
        }

        .attach {
          align-items: center;
          background: transparent;
          border: 0;
          border-radius: 50%;
          color: var(--sw-color-accent);
          cursor: not-allowed;
          display: inline-flex;
          height: 38px;
          justify-content: center;
          opacity: 0.55;
          padding: 0;
          width: 38px;
        }

        .input {
          background: transparent;
          border: 0;
          color: var(--sw-color-text);
          min-height: 38px;
          max-height: 118px;
          outline: 0;
          padding: 9px 0;
          resize: none;
          width: 100%;
        }

        .input::placeholder { color: color-mix(in srgb, var(--sw-color-text-muted) 65%, transparent); }

        .send {
          align-items: center;
          background: var(--sw-color-accent);
          border: 0;
          border-radius: 50%;
          color: var(--sw-color-accent-text);
          cursor: pointer;
          display: inline-flex;
          height: 44px;
          justify-content: center;
          padding: 0;
          width: 44px;
        }

        .send:disabled {
          cursor: default;
          opacity: 0.45;
        }

        .retry {
          background: transparent;
          border: 0;
          color: var(--sw-color-accent);
          cursor: pointer;
          margin-top: 8px;
          padding: 8px 0 0;
          text-decoration: underline;
        }

        .contact-row {
          margin-top: 10px;
        }

        .contact-trigger {
          align-items: center;
          background: transparent;
          border: 0;
          color: var(--sw-color-accent);
          cursor: pointer;
          display: inline-flex;
          gap: 10px;
          padding: 7px 2px;
        }

        .contact-capture {
          display: grid;
          gap: 8px;
          grid-template-columns: 1fr auto;
          margin-top: 8px;
        }

        .phone-input {
          background: var(--sw-color-surface);
          border: 1px solid var(--sw-color-border);
          border-radius: 12px;
          min-height: 42px;
          padding: 0 12px;
        }

        .phone-save {
          background: var(--sw-color-accent);
          border: 0;
          border-radius: 12px;
          color: var(--sw-color-accent-text);
          cursor: pointer;
          padding: 0 16px;
        }

        .footer-note {
          align-items: flex-start;
          border-top: 1px solid var(--sw-color-border);
          color: var(--sw-color-text-muted);
          display: flex;
          font-size: 13px;
          gap: 9px;
          margin-top: 14px;
          padding-top: 14px;
        }

        .mobile-actions {
          background: var(--sw-color-surface);
          border: 1px solid var(--sw-color-border);
          border-radius: 20px;
          box-shadow: var(--sw-shadow-launcher);
          display: none;
          gap: 0;
          grid-template-columns: repeat(3, 1fr);
          margin-top: 16px;
          overflow: hidden;
          width: min(520px, calc(100vw - 28px));
        }

        .mobile-action {
          align-items: center;
          background: transparent;
          border: 0;
          color: var(--sw-color-text);
          cursor: pointer;
          display: inline-flex;
          gap: 10px;
          justify-content: center;
          min-height: 62px;
          padding: 0 12px;
          text-decoration: none;
        }

        .mobile-action + .mobile-action { border-left: 1px solid var(--sw-color-border); }

        :host([theme="neutral"]) {
          --sw-color-accent: #334155;
          --sw-color-panel: #f8fafc;
          --sw-color-visitor: #e2e8f0;
          --sw-color-text: #0f172a;
          --sw-color-text-muted: #64748b;
        }

        :host([theme="contrast"]) {
          --sw-color-accent: #111827;
          --sw-color-panel: #ffffff;
          --sw-color-visitor: #d1d5db;
          --sw-color-text: #111827;
          --sw-color-text-muted: #4b5563;
        }

        @media (max-width: 720px) {
          :host {
            bottom: 14px;
            left: 14px;
            right: 14px;
          }

          .launcher {
            min-height: 56px;
          }

          .mobile-actions { display: grid; }

          .panel {
            border-radius: 24px;
            max-height: calc(100vh - 28px);
            width: calc(100vw - 28px);
          }

          .header {
            gap: 10px;
            grid-template-columns: 44px 1fr 38px 38px;
            min-height: 86px;
            padding: 18px;
          }

          .body { padding: 18px; }
          .composer-shell { padding: 14px 18px 18px; }
          .title { font-size: 19px; }
        }
      </style>

      <div id="root" class="root" part="root">
        <button id="launcher" class="launcher" part="launcher" type="button" aria-haspopup="dialog" aria-expanded="false">
          <span id="launcherIcon" class="launcher-icon" aria-hidden="true"></span>
          <span id="launcherLabel"></span>
        </button>

        <nav id="mobileActions" class="mobile-actions" part="mobile-actions" aria-label="Быстрые действия"></nav>

        <section id="panel" class="panel" part="panel" role="dialog" aria-modal="false" hidden>
          <header class="header" part="header">
            <div id="brandIcon" class="brand" part="brand" aria-hidden="true"></div>
            <div>
              <h2 id="title" class="title" part="header-title"></h2>
              <div class="status-line" part="status-line">
                <span class="status-dot" aria-hidden="true"></span>
                <span id="statusText"></span>
                <span aria-hidden="true">·</span>
                <span id="responseTime"></span>
              </div>
            </div>
            <button id="minimizeButton" class="icon-button" part="minimize-button" type="button"></button>
            <button id="closeButton" class="icon-button" part="close-button" type="button"></button>
          </header>

          <div class="body" part="body">
            <div id="log" class="log" part="message-list" role="log" aria-live="polite" aria-relevant="additions"></div>
            <div id="quickReplies" class="quick-replies" part="quick-replies"></div>
          </div>

          <div class="composer-shell" part="composer-shell">
            <form id="form" class="composer" part="composer">
              <button id="attachButton" class="attach" part="attach-button" type="button" disabled></button>
              <label id="inputLabel" class="visually-hidden" for="messageInput"></label>
              <textarea id="messageInput" class="input" part="input" rows="1"></textarea>
              <button id="sendButton" class="send" part="send-button" type="submit"></button>
            </form>
            <button id="retryButton" class="retry" part="retry-button" type="button" hidden></button>

            <div class="contact-row" part="contact-row">
              <button id="contactTrigger" class="contact-trigger" part="phone-trigger" type="button">
                <span aria-hidden="true">+</span>
                <span id="contactLabel"></span>
              </button>
            </div>

            <div id="contactCapture" class="contact-capture" part="phone-capture" hidden>
              <label class="visually-hidden" for="phoneInput"></label>
              <input id="phoneInput" class="phone-input" part="phone-input" inputmode="tel" autocomplete="tel" placeholder="+7 999 000-00-00" />
              <button id="phoneSaveButton" class="phone-save" part="phone-save-button" type="button">OK</button>
            </div>

            <div class="footer-note" part="footer-note">
              <span id="shieldIcon" class="inline-icon" aria-hidden="true"></span>
              <span id="footerNote"></span>
            </div>
          </div>
        </section>
      </div>
    </template>`,

  'granit-widget-message': String.raw`
    <template id="granit-widget-message">
      <style>
        :host {
          --message-background: var(--sw-color-surface, #ffffff);
          --message-align: flex-start;
          align-self: var(--message-align);
          background: var(--message-background);
          border: 1px solid var(--sw-color-border, rgba(84, 68, 52, 0.16));
          border-radius: var(--sw-radius-bubble, 16px);
          color: var(--sw-color-text, #27231f);
          display: block;
          max-width: min(82%, 430px);
          padding: 14px 16px;
        }

        :host([role="visitor"]) {
          --message-align: flex-end;
          --message-background: var(--sw-color-visitor, #efe2d5);
        }

        :host([role="system"]) {
          --message-align: center;
          --message-background: var(--sw-color-system, #f7f3ee);
          color: var(--sw-color-text-muted, #756d64);
          max-width: 94%;
        }

        :host([status="error"]) {
          border-color: #b42318;
        }

        p {
          margin: 0;
          white-space: pre-wrap;
          word-break: break-word;
        }

        small {
          color: var(--sw-color-text-muted, #756d64);
          display: block;
          font-size: 11px;
          margin-top: 7px;
          text-align: right;
        }

        .disclosure {
          align-items: center;
          color: var(--sw-color-text-muted, #756d64);
          display: flex;
          font-size: 12px;
          gap: 6px;
          margin-top: 10px;
        }

        [hidden] { display: none !important; }
      </style>
      <p id="text"></p>
      <div id="disclosure" class="disclosure" part="disclosure" hidden>
        <span id="sparkIcon" aria-hidden="true"></span>
        <span id="disclosureText"></span>
      </div>
      <small id="statusText" hidden></small>
    </template>`,
});

const getTemplate = (id) => {
  if (typeof document === 'undefined') return null;
  let template = document.getElementById(id);
  if (template instanceof HTMLTemplateElement) return template;

  const html = TEMPLATE_HTML[id];
  if (!html) return null;

  const wrapper = document.createElement('div');
  wrapper.innerHTML = html;
  template = wrapper.querySelector('template');
  if (!template) return null;
  document.head.append(template);
  return template;
};

const cloneTemplate = (id) => {
  const template = getTemplate(id);
  if (!template) throw new Error(`Template not found: ${id}`);
  return template.content.cloneNode(true);
};

export { cloneTemplate, getTemplate };
