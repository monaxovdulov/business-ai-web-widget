const SVG_NS = 'http://www.w3.org/2000/svg';

const createIcon = (name) => {
  const template = document.createElement('template');
  template.innerHTML = iconSvg(name);
  return template.content.firstElementChild || document.createTextNode('');
};

const setIcon = (element, name) => {
  element.replaceChildren(createIcon(name));
};

const iconSvg = (name) => {
  switch (name) {
    case 'brand':
      return '<svg viewBox="0 0 32 32" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 23h22L19 9l-4.5 8-3-4.8L5 23Z"/><path d="M19 9l3 14"/></svg>';
    case 'minus':
      return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 12h12"/></svg>';
    case 'close':
      return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
    case 'paperclip':
      return '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m21 8.5-9.7 9.7a5 5 0 0 1-7.1-7.1l10-10a3.2 3.2 0 0 1 4.5 4.5L8.6 15.7a1.5 1.5 0 0 1-2.1-2.1L15.8 4.3"/></svg>';
    case 'send':
      return '<svg viewBox="0 0 24 24" width="21" height="21" fill="currentColor"><path d="M3.7 20.3 21 3l-6.1 18.2-3.6-8.5-7.6 7.6Zm8.7-8.7 3.4 3.4 2.3-6.8-5.7 3.4Z"/></svg>';
    case 'loader':
      return '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3a9 9 0 1 0 9 9"/></svg>';
    case 'shield':
      return '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-5"/></svg>';
    case 'phone':
    case 'call':
      return '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3 5.2 2 2 0 0 1 5 3h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.4 2.1L8 11.6a16 16 0 0 0 4.4 4.4l2.2-2.2a2 2 0 0 1 2.1-.4c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2Z"/></svg>';
    case 'calculator':
    case 'calculation':
      return '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h2M12 11h2M16 11h0M8 15h2M12 15h2M16 15h0"/></svg>';
    case 'spark':
      return '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 1.9 5.6L20 11l-6.1 2.4L12 19l-1.9-5.6L4 11l6.1-2.4L12 3Z"/></svg>';
    case 'message':
    default:
      return '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a7.5 7.5 0 0 1-7.5 7.5H8l-5 2 1.6-4.4A7.5 7.5 0 1 1 21 12Z"/><path d="M8 11.5h8M8 14.5h5"/></svg>';
  }
};

export { SVG_NS, createIcon, setIcon };
