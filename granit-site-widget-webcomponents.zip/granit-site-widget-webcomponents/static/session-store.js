import { createPublicSessionId } from '../shared/site-widget-domain.js';

const STORAGE_PREFIX = 'granit-site-widget:session:';

const createSessionStore = (widgetInstanceId) => {
  const key = `${STORAGE_PREFIX}${widgetInstanceId}`;
  const storage = getLocalStorage();
  let memorySessionId = '';

  return {
    get() {
      const existing = storage?.getItem(key) || memorySessionId;
      if (existing) return existing;
      const created = createPublicSessionId();
      memorySessionId = created;
      try {
        storage?.setItem(key, created);
      } catch {
        // Browser privacy settings may block storage. The in-memory id still works for this tab.
      }
      return created;
    },

    set(publicSessionId) {
      if (!publicSessionId) return;
      memorySessionId = publicSessionId;
      try {
        storage?.setItem(key, publicSessionId);
      } catch {
        // Keep memory fallback.
      }
    },

    clear() {
      memorySessionId = '';
      try {
        storage?.removeItem(key);
      } catch {
        // Ignore storage errors.
      }
    },
  };
};

const getLocalStorage = () => {
  try {
    if (typeof window === 'undefined') return null;
    return window.localStorage;
  } catch {
    return null;
  }
};

export { createSessionStore };
