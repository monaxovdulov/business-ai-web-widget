const WIDGET_EVENT_PREFIX = 'granit-site-widget';

const emitWidgetEvent = (element, name, detail = {}) => {
  element.dispatchEvent(
    new CustomEvent(`${WIDGET_EVENT_PREFIX}:${name}`, {
      bubbles: true,
      composed: true,
      detail,
    }),
  );
};

export { WIDGET_EVENT_PREFIX, emitWidgetEvent };
