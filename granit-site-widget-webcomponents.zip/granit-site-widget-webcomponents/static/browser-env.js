const readBrowserEnvironment = () => {
  const href = typeof window === 'undefined' ? '' : window.location.href;
  const search = typeof window === 'undefined' ? '' : window.location.search;
  const title = typeof document === 'undefined' ? '' : document.title;
  const referrer = typeof document === 'undefined' ? '' : document.referrer;
  const locale = typeof navigator === 'undefined' ? '' : navigator.language;

  let timezone = '';
  try {
    timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
  } catch {
    timezone = '';
  }

  return {
    href,
    search,
    title,
    referrer,
    locale,
    timezone,
    now: new Date().toISOString(),
  };
};

export { readBrowserEnvironment };
