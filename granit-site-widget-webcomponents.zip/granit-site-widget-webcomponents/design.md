# Design contract: Granit Site Widget

This document defines the portable UI contract for the public website widget. It is independent of React, Vue, Svelte, Tailwind, or any specific build tool.

## Anatomy

```text
<granit-site-widget>
  Launcher
  MobileActions
  Panel
    Header
      BrandIcon
      Title
      StatusLine
      MinimizeButton
      CloseButton
    Body
      MessageList
        <granit-widget-message>
      QuickReplies
    ComposerShell
      Composer
        AttachButton(disabled)
        TextArea
        SendButton
      RetryButton
      ContactCapture
      FooterNote
```

## States

| State | Trigger | Visible surface |
|---|---|---|
| closed | default | launcher, mobile actions on small screens |
| open idle | launcher click / `open()` | panel, intro message, quick replies |
| composing | textarea input | panel, enabled send button |
| submitting | form submit | pending visitor message, disabled input, loader icon |
| replied | backend `automation.status="replied"` | assistant bubble with disclosure |
| fallback | backend `fallback` or unknown status | system manager-review bubble |
| disabled | backend `disabled` | system manager-review bubble |
| error | network/HTTP failure | visitor message error status, retry button |

## Default copy

| Token | Text |
|---|---|
| launcherLabel | `Написать` |
| headerTitle | `Поможем с заказом` |
| headerStatus | `Онлайн` |
| headerResponseTime | `обычно отвечаем за 2 минуты` |
| placeholder | `Напишите сообщение...` |
| phoneCaptureLabel | `Добавить телефон для ответа` |
| phoneSavedLabel | `Телефон добавлен` |
| fallbackMessage | `Заявку получили. Менеджер уточнит детали и ответит вам.` |
| disabledMessage | `Заявку получили. Менеджер ответит после проверки.` |
| errorMessage | `Сообщение не отправилось. Проверьте связь и повторите.` |

## CSS custom properties

```css
granit-site-widget {
  --sw-color-accent: #9d8062;
  --sw-color-accent-text: #ffffff;
  --sw-color-panel: #fffaf5;
  --sw-color-surface: #ffffff;
  --sw-color-visitor: #efe2d5;
  --sw-color-system: #f7f3ee;
  --sw-color-text: #27231f;
  --sw-color-text-muted: #756d64;
  --sw-color-border: rgba(84, 68, 52, 0.16);
  --sw-radius-panel: 28px;
  --sw-radius-bubble: 16px;
  --sw-radius-control: 999px;
  --sw-shadow-panel: 0 28px 90px rgba(35, 29, 22, 0.18);
  --sw-shadow-launcher: 0 12px 36px rgba(35, 29, 22, 0.18);
  --sw-font-family: Inter, system-ui, sans-serif;
}
```

## Exposed parts

| Part | Element |
|---|---|
| `root` | root wrapper |
| `launcher` | closed-state button |
| `mobile-actions` | mobile quick action rail |
| `mobile-action` | one mobile action |
| `panel` | open panel |
| `header` | panel header |
| `brand` | round brand icon |
| `header-title` | panel title |
| `status-line` | online/status row |
| `minimize-button` | header minimize button |
| `close-button` | header close button |
| `body` | panel body |
| `message-list` | message log |
| `message` | message bubble host |
| `message-assistant` | assistant bubble host |
| `message-visitor` | visitor bubble host |
| `message-system` | system bubble host |
| `quick-replies` | quick reply row |
| `quick-reply` | one quick reply |
| `composer-shell` | bottom shell |
| `composer` | input form |
| `attach-button` | disabled attach button |
| `input` | textarea |
| `send-button` | submit button |
| `retry-button` | retry button |
| `contact-row` | phone row |
| `phone-trigger` | open phone capture button |
| `phone-capture` | phone capture row |
| `phone-input` | phone input |
| `phone-save-button` | phone save button |
| `footer-note` | bottom note |

## Layout rules

Desktop:

```text
position: fixed bottom-right by default
panel width: min(640px, viewport - 36px)
panel max-height: min(720px, viewport - 48px)
launcher remains outside document flow
```

Mobile:

```text
host inset: 14px from left/right/bottom
panel width: viewport - 28px
mobile actions are visible only while closed
```

Inline:

```html
<granit-site-widget position="inline" open></granit-site-widget>
```

In inline mode, the host is `position: relative` and can be placed inside a page section.

## Rendering constraints

- Visitor text and backend text are rendered as plain text.
- Line breaks are preserved with `white-space: pre-wrap`.
- Backend HTML is not rendered.
- Assistant disclosure is shown only for persisted `replied` response text.
- Fallback and disabled responses use system bubbles.

## Accessibility checklist

- Launcher has `aria-haspopup="dialog"` and synchronized `aria-expanded`.
- Panel uses `role="dialog"`.
- Message log uses `role="log"` and `aria-live="polite"`.
- Header icon buttons have aria labels.
- Textarea has a hidden label.
- Enter sends; Shift+Enter inserts a new line; Escape closes the panel.
- Focus moves to textarea when the panel opens.

## Theme presets

| Theme | Use |
|---|---|
| `memorial-soft` | warm stone/beige landing pages |
| `neutral` | generic business sites |
| `contrast` | stricter high-contrast pages |

Any landing can override the preset through CSS variables on `granit-site-widget`.
