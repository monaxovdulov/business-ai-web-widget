# Granit Site Widget Web Components

Framework-agnostic public website widget implemented with native browser APIs, Custom Elements, Shadow DOM, browser ES modules, and a small shared domain module.

This version is rewritten in the style of the reference WebComponents project:

- no React/Vue/Svelte runtime;
- no bundler requirement;
- no TypeScript build step;
- no runtime npm dependencies;
- components do not call `fetch` directly;
- public HTTP access is isolated in `static/api.js`;
- state transitions, request building, response mapping, config normalization, and validation live in `shared/site-widget-domain.js`;
- UI templates are declared as `<template>` fragments and cloned synchronously;
- dynamic visitor/backend text is rendered with `textContent`, attributes, and DOM methods, not `innerHTML`.

## Package layout

```text
.
├── shared/
│   └── site-widget-domain.js        # shared config, reducer, validation, request/response mapping
├── static/
│   ├── api.js                       # only browser module that performs fetch
│   ├── browser-env.js               # page URL, title, referrer, locale, timezone snapshot
│   ├── events.js                    # composed CustomEvent helper
│   ├── loader.js                    # script-tag loader
│   ├── session-store.js             # public_session_id storage
│   ├── site-widget.esm.js           # ESM entry
│   └── components/
│       ├── granit-site-widget.html
│       ├── granit-site-widget.js
│       ├── widget-message.html
│       ├── widget-message.js
│       ├── template-registry.js
│       └── icons.js
├── dist/                            # CDN alias copy of static/
├── examples/
├── tests/
├── design.md
├── design-tokens.json
└── ARCHITECTURE.md
```

`static/` is the source form. `dist/` is included as a publish-compatible alias so old CDN paths like `/dist/loader.js` remain easy to use.

## Fast integration

```html
<script
  async
  src="https://cdn.example.com/site-widget/v2/dist/loader.js"
  data-granit-site-widget-loader
  data-widget-instance-id="memorial-main"
  data-api-base-url="https://ops.example.com"
  data-theme="memorial-soft"
  data-phone-href="tel:+79990000000">
</script>
```

Local demo without backend:

```html
<script
  async
  src="../dist/loader.js"
  data-granit-site-widget-loader
  data-mock="true"
  data-widget-instance-id="memorial-main">
</script>
```

## Direct Web Component integration

```html
<script type="module" src="https://cdn.example.com/site-widget/v2/dist/site-widget.esm.js"></script>

<granit-site-widget
  widget-instance-id="memorial-main"
  api-base-url="https://ops.example.com"
  theme="memorial-soft"
  phone-href="tel:+79990000000">
</granit-site-widget>
```

The same element can be placed in plain HTML, CMS custom HTML blocks, Astro, React, Vue, Svelte, Next, Nuxt, and server-rendered pages because it is a native custom element.

## Programmatic integration

```js
import { mountSiteWidget } from './dist/site-widget.esm.js';

const widget = mountSiteWidget({
  widgetInstanceId: 'memorial-main',
  apiBaseUrl: 'https://ops.example.com',
  theme: 'memorial-soft',
});

widget.open();
widget.sendMessage('Сколько стоит памятник с установкой?');
```

## Runtime API request

On submit the widget sends only one public request:

```http
POST /public/intake/site-widget/messages
Content-Type: application/json
Accept: application/json
```

Request body is built in `shared/site-widget-domain.js`:

```json
{
  "schema_version": "site_widget.v1",
  "event_type": "site_widget.message_submitted",
  "idempotency_key": "site-widget:sws_...",
  "submitted_at": "2026-06-17T12:00:00.000Z",
  "public_session_id": "sws_...",
  "source": {
    "channel": "site_widget",
    "page_url": "https://example.com/page",
    "widget_instance_id": "memorial-main",
    "page_title": "Landing title",
    "referrer_url": "https://referrer.example"
  },
  "contact": {
    "phone": "+79990000000",
    "preferred_contact": "phone"
  },
  "message": {
    "role": "visitor",
    "text": "Сколько стоит памятник с установкой?"
  },
  "visitor_context": {
    "locale": "ru-RU",
    "timezone": "Europe/Moscow"
  }
}
```

The widget renders AI text only when the backend response maps to:

```json
{
  "automation": {
    "status": "replied",
    "reply": {
      "text": "..."
    }
  }
}
```

For `fallback` and `disabled`, it renders a manager-review system message.

## Attributes

| Attribute | Default | Purpose |
|---|---|---|
| `api-base-url` | `""` | Backend base URL without trailing slash. Required when `mock` is false. |
| `widget-instance-id` | `default` | Public widget instance key. |
| `theme` | `memorial-soft` | Named theme: `memorial-soft`, `neutral`, `contrast`, or custom CSS variable theme. |
| `position` | `bottom-right` | `bottom-right`, `bottom-left`, or `inline`. |
| `mock` | absent | Enables local mock responses. |
| `open` | absent | Opens the panel initially. |
| `launcher-label` | `Написать` | Closed-state button text. |
| `header-title` | `Поможем с заказом` | Panel title. |
| `header-status` | `Онлайн` | Header status text. |
| `header-response-time` | `обычно отвечаем за 2 минуты` | Header response-time text. |
| `intro-message` | built-in | First assistant message. |
| `placeholder` | `Напишите сообщение...` | Composer placeholder. |
| `phone-href` | `""` | Optional `tel:` link for mobile call action. |
| `quick-replies` | built-in | JSON array or pipe-separated list. |
| `mobile-actions` | built-in | JSON array or pipe-separated list. |
| `max-message-length` | `2000` | Client-side draft length guard. |

## CSS customization

The component uses Shadow DOM. Host pages customize it through CSS variables and `::part()`.

```css
granit-site-widget {
  --sw-color-accent: #9d8062;
  --sw-color-panel: #fffaf3;
  --sw-color-visitor: #efe2d5;
  --sw-color-text: #27231f;
  --sw-radius-panel: 28px;
  --sw-shadow-panel: 0 28px 90px rgba(35, 29, 22, 0.18);
  --sw-font-family: Inter, system-ui, sans-serif;
}

granit-site-widget::part(launcher) {
  letter-spacing: 0.01em;
}

granit-site-widget::part(panel) {
  backdrop-filter: blur(10px);
}
```

Full token and part contract: `design.md`.

## Events

Events bubble and cross the Shadow DOM boundary.

```js
document.addEventListener('granit-site-widget:message-submitted', (event) => {
  console.log(event.detail);
});
```

| Event | Emitted when |
|---|---|
| `granit-site-widget:ready` | Component is mounted and initialized. |
| `granit-site-widget:open` | Panel opens. |
| `granit-site-widget:close` | Panel closes. |
| `granit-site-widget:message-submitted` | Request is built and submission starts. |
| `granit-site-widget:response` | Backend or mock response is mapped to UI state. |
| `granit-site-widget:error` | Network or contract failure reaches the widget. |
| `granit-site-widget:phone-saved` | Visitor saved phone locally before submit. |

## Security and boundary rules

- Browser components do not call AI providers.
- Browser components do not receive or render internal `leadId`, `conversationId`, model names, provider metadata, or AI credentials.
- `public_session_id` is the only value stored in `localStorage`.
- Each submit gets a client-generated `idempotency_key`.
- Dynamic text is rendered with `textContent` or safe DOM attributes.
- The component does not render backend HTML.
- CORS allowlist remains a backend responsibility.

## Local checks

```bash
npm test
```

The test suite checks request construction, UTM parsing, response mapping, reducer transitions, syntax, and that the main component file contains no inline `fetch` or dynamic `innerHTML` rendering.
