import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {
  applyWidgetAction,
  buildSiteWidgetMessageRequest,
  createIdempotencyKey,
  createWidgetState,
  mapSiteWidgetResponse,
  normalizeWidgetConfig,
  parseQuickReplies,
  parseUtm,
} from '../shared/site-widget-domain.js';

const config = normalizeWidgetConfig({
  apiBaseUrl: 'https://ops.example.test/',
  widgetInstanceId: 'memorial-main',
  mock: false,
});

assert.equal(config.apiBaseUrl, 'https://ops.example.test');
assert.equal(config.widgetInstanceId, 'memorial-main');
assert.deepEqual(parseQuickReplies('A|B'), [
  { label: 'A', value: 'A' },
  { label: 'B', value: 'B' },
]);
assert.deepEqual(parseUtm('?utm_source=yandex&utm_medium=cpc&utm_campaign=summer'), {
  source: 'yandex',
  medium: 'cpc',
  campaign: 'summer',
});

const idempotencyKey = createIdempotencyKey('sws_test');
const request = buildSiteWidgetMessageRequest({
  config,
  text: 'Сколько стоит памятник?',
  publicSessionId: 'sws_test',
  idempotencyKey,
  contact: { phone: '+79990000000', preferred_contact: 'phone' },
  environment: {
    href: 'https://example.test/?utm_source=yandex',
    search: '?utm_source=yandex',
    title: 'Landing',
    referrer: 'https://referrer.test',
    locale: 'ru-RU',
    timezone: 'Europe/Moscow',
    now: '2026-06-17T12:00:00.000Z',
  },
});

assert.equal(request.schema_version, 'site_widget.v1');
assert.equal(request.event_type, 'site_widget.message_submitted');
assert.equal(request.idempotency_key, idempotencyKey);
assert.equal(request.public_session_id, 'sws_test');
assert.equal(request.source.channel, 'site_widget');
assert.equal(request.source.widget_instance_id, 'memorial-main');
assert.equal(request.source.page_url, 'https://example.test/?utm_source=yandex');
assert.equal(request.message.role, 'visitor');
assert.equal(request.message.text, 'Сколько стоит памятник?');
assert.equal(request.contact.phone, '+79990000000');
assert.equal(request.contact.preferred_contact, 'phone');
assert.equal(request.visitor_context.locale, 'ru-RU');

const response = mapSiteWidgetResponse(
  {
    public_session_id: 'sws_server',
    automation: {
      status: 'replied',
      reply: { text: 'Стоимость зависит от модели.' },
    },
  },
  config,
);
assert.equal(response.status, 'replied');
assert.equal(response.publicSessionId, 'sws_server');
assert.equal(response.replyText, 'Стоимость зависит от модели.');

let state = createWidgetState({ config });
state = applyWidgetAction(state, {
  type: 'submit.started',
  text: 'Нужен расчет',
  idempotencyKey: 'idem_1',
});
assert.equal(state.submitting, true);
assert.equal(state.pending.idempotencyKey, 'idem_1');
state = applyWidgetAction(state, { type: 'visitor.persisted', text: 'Нужен расчет' });
state = applyWidgetAction(state, { type: 'assistant.replied', text: 'Подготовим расчет.' });
assert.equal(state.submitting, false);
assert.equal(state.pending, null);
assert.equal(state.messages.at(-1).role, 'assistant');

const componentSource = await readFile(
  new URL('../static/components/granit-site-widget.js', import.meta.url),
  'utf8',
);
assert.equal(componentSource.includes('fetch('), false, 'components must not call fetch directly');
assert.equal(componentSource.includes('innerHTML'), false, 'dynamic component must not render with innerHTML');

console.log('domain.test.mjs passed');
