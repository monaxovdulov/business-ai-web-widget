# Checks

Run:

```bash
npm test
```

Current checks:

- domain request builder creates `site_widget.v1` request;
- UTM parser maps standard UTM keys;
- response mapper accepts `automation.status="replied"`;
- reducer persists visitor and assistant state transitions;
- main component source contains no inline `fetch` call;
- main component source contains no dynamic `innerHTML` rendering;
- key browser modules pass `node --check`.
