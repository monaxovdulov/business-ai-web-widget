# Architecture: Granit Site Widget Web Components

Status: rewritten native Web Component package

## Decision

The widget is implemented as a framework-agnostic Custom Element:

```text
Landing page
  -> dist/loader.js or dist/site-widget.esm.js
  -> <granit-site-widget>
  -> Shadow DOM templates
  -> shared domain reducer/request mapper
  -> static/api.js
  -> POST /public/intake/site-widget/messages
```

The rewrite keeps the Web Component boundary but changes the implementation style to match the supplied native WebComponents reference project.

## Applied practices from the reference project

| Practice | Widget implementation |
|---|---|
| Browser ES modules | All browser code is native ESM. |
| No framework runtime | No React/Vue/Svelte/lit dependency. |
| No bundler requirement | `static/` and `dist/` are directly loadable by the browser. |
| Templates | Components clone `<template>` fragments synchronously through `template-registry.js`; `.html` fragments are co-located for inspection and portability. |
| API facade | Only `static/api.js` performs `fetch`. Component files do not call `fetch`. |
| Shared domain logic | `shared/site-widget-domain.js` owns config normalization, reducer transitions, validation, request building, UTM parsing, and response mapping. |
| Declarative component updates | Main component updates pre-queried template nodes and uses `replaceChildren()` for repeated message and action nodes. |
| Event-driven component boundary | Public events are composed `CustomEvent`s with `granit-site-widget:*` names. |
| No untrusted HTML rendering | Visitor and backend text are rendered with `textContent` and DOM attributes. |

## Runtime modules

```text
shared/site-widget-domain.js
  -> DEFAULT_WIDGET_CONFIG
  -> normalizeWidgetConfig
  -> applyWidgetAction
  -> buildWidgetViewModel
  -> buildSiteWidgetMessageRequest
  -> mapSiteWidgetResponse

static/components/granit-site-widget.js
  -> custom element lifecycle
  -> DOM event handling
  -> state/action calls
  -> rendering through templates

static/components/widget-message.js
  -> one message bubble custom element

static/api.js
  -> sendSiteWidgetMessage
  -> mockSiteWidgetMessage

static/session-store.js
  -> public_session_id storage

static/loader.js
  -> script-tag auto-mount
```

## State flow

```text
input/change/click
  -> component event handler
  -> applyWidgetAction(state, action)
  -> buildWidgetViewModel(state, config)
  -> DOM update
```

Submit path:

```text
draft
  -> validateDraft
  -> createIdempotencyKey
  -> applyWidgetAction(submit.started)
  -> buildSiteWidgetMessageRequest
  -> sendSiteWidgetMessage in api.js
  -> mapSiteWidgetResponse
  -> applyWidgetAction(assistant.replied | system.message | submit.failed)
```

## Backend boundary

The widget remains a thin public-contract client. It sends a validated public request shape and renders only display-safe public response fields. It does not infer whether an AI answer is allowed.

Backend remains responsible for:

- validating `SiteWidgetMessageRequest`;
- saving inbound before any AI branch;
- checking manager takeover / send gate;
- saving outbound AI reply before it is exposed;
- returning `automation.status` and display-safe reply text.

## Public response rendering rule

| Backend automation status | Widget action |
|---|---|
| `replied` with reply text | Render assistant bubble with disclosure. |
| `fallback` | Render manager-review system bubble. |
| `disabled` | Render manager-review system bubble. |
| unknown status | Render fallback system bubble. |
| network error | Mark visitor message as error and show retry. |

## Non-goals

- No AI provider code in the browser.
- No manager UI in the widget.
- No iframe isolation.
- No client-side storage of conversation history.
- No file upload implementation; attach button is present but disabled.
- No framework wrappers; React/Vue can use the native custom element directly.

## Migration note from the previous package

The previous package used TypeScript source and a compiled `dist/`. This rewrite uses browser-loadable JavaScript source directly. `dist/` is kept as a publish alias copy so CDN integrations can still use `/dist/loader.js`.
