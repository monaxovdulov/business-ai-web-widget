const SCHEMA_VERSION = 'site_widget.v1';
const EVENT_TYPE_MESSAGE_SUBMITTED = 'site_widget.message_submitted';

const DEFAULT_QUICK_REPLIES = Object.freeze([
  { label: 'Нужен расчет', value: 'Нужен расчет памятника с установкой' },
  { label: 'Есть вопрос', value: 'Здравствуйте, у меня есть вопрос по заказу' },
  { label: 'Хочу каталог', value: 'Хочу посмотреть каталог памятников' },
]);

const DEFAULT_MOBILE_ACTIONS = Object.freeze([
  { id: 'call', label: 'Позвонить', icon: 'phone' },
  { id: 'message', label: 'Написать', icon: 'message' },
  {
    id: 'calculation',
    label: 'Расчет',
    icon: 'calculator',
    value: 'Нужен расчет памятника',
  },
]);

const DEFAULT_WIDGET_CONFIG = Object.freeze({
  apiBaseUrl: '',
  widgetInstanceId: 'default',
  theme: 'memorial-soft',
  position: 'bottom-right',
  mock: false,

  launcherLabel: 'Написать',
  headerTitle: 'Поможем с заказом',
  headerStatus: 'Онлайн',
  headerResponseTime: 'обычно отвечаем за 2 минуты',
  introMessage:
    'Здравствуйте! 👋\nПодскажем по памятнику, рассчитаем стоимость и оформим заказ дистанционно.\nОпишите задачу или выберите вариант ниже.',
  placeholder: 'Напишите сообщение...',
  disclosureText:
    'Ответ подготовлен автоматически. Менеджер проверит детали при необходимости.',
  footerNote:
    'Расчет бесплатный. Точную стоимость подтвердит менеджер после уточнения деталей.',
  phoneCaptureLabel: 'Добавить телефон для ответа',
  phoneSavedLabel: 'Телефон добавлен',
  fallbackMessage: 'Заявку получили. Менеджер уточнит детали и ответит вам.',
  disabledMessage: 'Заявку получили. Менеджер ответит после проверки.',
  errorMessage: 'Сообщение не отправилось. Проверьте связь и повторите.',
  retryLabel: 'Повторить',
  sendLabel: 'Отправить',
  attachLabel: 'Приложить файл',
  closeLabel: 'Закрыть',
  minimizeLabel: 'Свернуть',
  callLabel: 'Позвонить',

  phoneHref: '',
  privacyUrl: '',
  quickReplies: DEFAULT_QUICK_REPLIES,
  mobileActions: DEFAULT_MOBILE_ACTIONS,
  maxMessageLength: 2000,
});

const ATTRIBUTE_MAP = Object.freeze({
  'api-base-url': 'apiBaseUrl',
  'widget-instance-id': 'widgetInstanceId',
  theme: 'theme',
  position: 'position',
  mock: 'mock',
  'launcher-label': 'launcherLabel',
  'header-title': 'headerTitle',
  'header-status': 'headerStatus',
  'header-response-time': 'headerResponseTime',
  'intro-message': 'introMessage',
  placeholder: 'placeholder',
  'disclosure-text': 'disclosureText',
  'footer-note': 'footerNote',
  'phone-capture-label': 'phoneCaptureLabel',
  'phone-saved-label': 'phoneSavedLabel',
  'fallback-message': 'fallbackMessage',
  'disabled-message': 'disabledMessage',
  'error-message': 'errorMessage',
  'retry-label': 'retryLabel',
  'send-label': 'sendLabel',
  'attach-label': 'attachLabel',
  'close-label': 'closeLabel',
  'minimize-label': 'minimizeLabel',
  'call-label': 'callLabel',
  'phone-href': 'phoneHref',
  'privacy-url': 'privacyUrl',
  'max-message-length': 'maxMessageLength',
});

const OBSERVED_ATTRIBUTES = Object.freeze([
  ...Object.keys(ATTRIBUTE_MAP),
  'quick-replies',
  'mobile-actions',
  'open',
]);

const normalizeWidgetConfig = (input = {}) => {
  const merged = {
    ...DEFAULT_WIDGET_CONFIG,
    ...input,
  };

  const maxMessageLength = Number(merged.maxMessageLength);

  return {
    ...merged,
    apiBaseUrl: trimTrailingSlash(stringValue(merged.apiBaseUrl)),
    widgetInstanceId: stringValue(merged.widgetInstanceId) || 'default',
    theme: stringValue(merged.theme) || DEFAULT_WIDGET_CONFIG.theme,
    position: normalizePosition(merged.position),
    mock: Boolean(merged.mock),
    phoneHref: stringValue(merged.phoneHref),
    privacyUrl: stringValue(merged.privacyUrl),
    maxMessageLength:
      Number.isInteger(maxMessageLength) && maxMessageLength > 0
        ? Math.min(maxMessageLength, 10000)
        : DEFAULT_WIDGET_CONFIG.maxMessageLength,
    quickReplies: normalizeQuickReplies(
      merged.quickReplies ?? DEFAULT_WIDGET_CONFIG.quickReplies,
    ),
    mobileActions: normalizeMobileActions(
      merged.mobileActions ?? DEFAULT_WIDGET_CONFIG.mobileActions,
    ),
  };
};

const readConfigFromElement = (element) => {
  const raw = {};

  for (const [attributeName, configKey] of Object.entries(ATTRIBUTE_MAP)) {
    if (!element.hasAttribute(attributeName)) continue;
    const value = element.getAttribute(attributeName);
    if (value === null) continue;

    if (configKey === 'mock') raw.mock = parseBooleanAttribute(value);
    else if (configKey === 'maxMessageLength') raw.maxMessageLength = Number(value);
    else raw[configKey] = value;
  }

  if (element.hasAttribute('quick-replies')) {
    raw.quickReplies = parseQuickReplies(element.getAttribute('quick-replies') || '');
  }

  if (element.hasAttribute('mobile-actions')) {
    raw.mobileActions = parseMobileActions(element.getAttribute('mobile-actions') || '');
  }

  return normalizeWidgetConfig(raw);
};

const applyOptionsToElement = (element, options = {}) => {
  const config = normalizeWidgetConfig(options);

  setAttributeIfValue(element, 'api-base-url', config.apiBaseUrl);
  setAttributeIfValue(element, 'widget-instance-id', config.widgetInstanceId);
  setAttributeIfValue(element, 'theme', config.theme);
  setAttributeIfValue(element, 'position', config.position);
  setAttributeIfValue(element, 'launcher-label', config.launcherLabel);
  setAttributeIfValue(element, 'header-title', config.headerTitle);
  setAttributeIfValue(element, 'header-status', config.headerStatus);
  setAttributeIfValue(element, 'header-response-time', config.headerResponseTime);
  setAttributeIfValue(element, 'intro-message', config.introMessage);
  setAttributeIfValue(element, 'placeholder', config.placeholder);
  setAttributeIfValue(element, 'disclosure-text', config.disclosureText);
  setAttributeIfValue(element, 'footer-note', config.footerNote);
  setAttributeIfValue(element, 'phone-capture-label', config.phoneCaptureLabel);
  setAttributeIfValue(element, 'phone-saved-label', config.phoneSavedLabel);
  setAttributeIfValue(element, 'fallback-message', config.fallbackMessage);
  setAttributeIfValue(element, 'disabled-message', config.disabledMessage);
  setAttributeIfValue(element, 'error-message', config.errorMessage);
  setAttributeIfValue(element, 'retry-label', config.retryLabel);
  setAttributeIfValue(element, 'send-label', config.sendLabel);
  setAttributeIfValue(element, 'attach-label', config.attachLabel);
  setAttributeIfValue(element, 'close-label', config.closeLabel);
  setAttributeIfValue(element, 'minimize-label', config.minimizeLabel);
  setAttributeIfValue(element, 'call-label', config.callLabel);
  setAttributeIfValue(element, 'phone-href', config.phoneHref);
  setAttributeIfValue(element, 'privacy-url', config.privacyUrl);
  setAttributeIfValue(element, 'max-message-length', String(config.maxMessageLength));

  if (config.mock) element.setAttribute('mock', 'true');
  if (options.open) element.setAttribute('open', '');
  if (config.quickReplies.length > 0) {
    element.setAttribute('quick-replies', JSON.stringify(config.quickReplies));
  }
  if (config.mobileActions.length > 0) {
    element.setAttribute('mobile-actions', JSON.stringify(config.mobileActions));
  }

  if (options.attributes && typeof options.attributes === 'object') {
    for (const [name, value] of Object.entries(options.attributes)) {
      element.setAttribute(name, String(value));
    }
  }
};

const createWidgetState = ({ config, open = false, now = new Date() } = {}) => {
  const normalized = normalizeWidgetConfig(config);
  return buildWidgetState({
    open: Boolean(open),
    submitting: false,
    draft: '',
    contactPhone: '',
    contactCaptureOpen: false,
    pending: null,
    messages: [
      createWidgetMessage({
        role: 'assistant',
        text: normalized.introMessage,
        createdAt: now.toISOString(),
      }),
    ],
  });
};

const buildWidgetState = (state) => ({
  ...state,
  open: Boolean(state.open),
  submitting: Boolean(state.submitting),
  draft: stringValue(state.draft),
  contactPhone: stringValue(state.contactPhone),
  contactCaptureOpen: Boolean(state.contactCaptureOpen),
  pending: state.pending || null,
  messages: Array.isArray(state.messages) ? state.messages : [],
});

const buildWidgetViewModel = (state, config) => {
  const normalizedState = buildWidgetState(state);
  const normalizedConfig = normalizeWidgetConfig(config);
  const draft = normalizedState.draft.trim();
  const draftError = validateDraft(draft, normalizedConfig);

  return {
    ...normalizedState,
    canSend: draft.length > 0 && !draftError && !normalizedState.submitting,
    draftError,
    showQuickReplies:
      !normalizedState.submitting && normalizedConfig.quickReplies.length > 0,
    contactLabel: normalizedState.contactPhone
      ? normalizedConfig.phoneSavedLabel
      : normalizedConfig.phoneCaptureLabel,
  };
};

const applyWidgetAction = (state, action) => {
  const current = buildWidgetState(state);
  const type = action?.type;

  if (type === 'open') return { ...current, open: true };
  if (type === 'close') return { ...current, open: false };
  if (type === 'draft.changed') {
    return { ...current, draft: stringValue(action.value) };
  }
  if (type === 'contact.capture.toggled') {
    return {
      ...current,
      contactCaptureOpen:
        typeof action.open === 'boolean' ? action.open : !current.contactCaptureOpen,
    };
  }
  if (type === 'contact.phone.saved') {
    return {
      ...current,
      contactPhone: stringValue(action.phone),
      contactCaptureOpen: false,
    };
  }
  if (type === 'submit.started') {
    const text = stringValue(action.text).trim();
    const idempotencyKey = stringValue(action.idempotencyKey);
    if (!text || !idempotencyKey || current.submitting) return current;
    return {
      ...current,
      submitting: true,
      draft: '',
      pending: { text, idempotencyKey },
      messages: [
        ...clearErrorStatuses(current.messages),
        createWidgetMessage({ role: 'visitor', text, status: 'pending' }),
      ],
    };
  }
  if (type === 'retry.started') {
    if (!current.pending) return current;
    return {
      ...current,
      submitting: true,
      messages: current.messages
        .filter((message) => message.status !== 'error')
        .map((message) => {
          if (message.role !== 'visitor') return message;
          if (message.text !== current.pending.text) return message;
          return { ...message, status: 'pending' };
        }),
    };
  }
  if (type === 'visitor.persisted') {
    const text = stringValue(action.text).trim();
    return {
      ...current,
      messages: current.messages.map((message) => {
        if (message.role !== 'visitor') return message;
        if (message.text !== text || message.status !== 'pending') return message;
        return { ...message, status: 'sent' };
      }),
    };
  }
  if (type === 'assistant.replied') {
    const text = stringValue(action.text).trim();
    return finishSubmit({
      ...current,
      messages: text
        ? [
            ...current.messages,
            createWidgetMessage({
              role: 'assistant',
              text,
              disclosure: true,
            }),
          ]
        : current.messages,
    });
  }
  if (type === 'system.message') {
    const text = stringValue(action.text).trim();
    return finishSubmit({
      ...current,
      messages: text
        ? [...current.messages, createWidgetMessage({ role: 'system', text })]
        : current.messages,
    });
  }
  if (type === 'submit.failed') {
    const text = stringValue(action.text).trim();
    return {
      ...current,
      submitting: false,
      messages: [
        ...current.messages.map((message) => {
          if (message.role === 'visitor' && message.status === 'pending') {
            return { ...message, status: 'error' };
          }
          return message;
        }),
        createWidgetMessage({ role: 'system', text, status: 'error' }),
      ],
    };
  }

  return current;
};

const validateDraft = (text, config = DEFAULT_WIDGET_CONFIG) => {
  const normalizedConfig = normalizeWidgetConfig(config);
  const normalized = stringValue(text).trim();
  if (!normalized) return 'empty_message';
  if (normalized.length > normalizedConfig.maxMessageLength) {
    return 'message_too_long';
  }
  return null;
};

const createWidgetMessage = ({
  id = createClientId('msg'),
  role,
  text,
  status = 'sent',
  disclosure = false,
  createdAt = new Date().toISOString(),
}) => ({
  id,
  role,
  text: stringValue(text),
  status,
  disclosure: Boolean(disclosure),
  createdAt,
});

const buildSiteWidgetMessageRequest = ({
  config,
  text,
  publicSessionId,
  idempotencyKey,
  contact,
  environment = {},
  privacyPolicyAccepted = false,
}) => {
  const normalizedConfig = normalizeWidgetConfig(config);
  const submittedAt = environment.now || new Date().toISOString();
  const source = compactRecord({
    channel: 'site_widget',
    page_url: stringValue(environment.href),
    widget_instance_id: normalizedConfig.widgetInstanceId,
    page_title: stringValue(environment.title),
    referrer_url: stringValue(environment.referrer),
    utm: parseUtm(environment.search || ''),
  });
  const normalizedContact = compactRecord({
    name: stringValue(contact?.name),
    phone: stringValue(contact?.phone),
    email: stringValue(contact?.email),
    preferred_contact: stringValue(contact?.preferred_contact),
    city: stringValue(contact?.city),
  });

  return compactRecord({
    schema_version: SCHEMA_VERSION,
    event_type: EVENT_TYPE_MESSAGE_SUBMITTED,
    idempotency_key: stringValue(idempotencyKey),
    submitted_at: submittedAt,
    public_session_id: stringValue(publicSessionId),
    source,
    contact: Object.keys(normalizedContact).length > 0 ? normalizedContact : undefined,
    message: {
      role: 'visitor',
      text: stringValue(text).trim(),
    },
    visitor_context: compactRecord({
      locale: stringValue(environment.locale),
      timezone: stringValue(environment.timezone),
    }),
    consent: privacyPolicyAccepted ? { privacy_policy: true } : undefined,
  });
};

const mapSiteWidgetResponse = (body, config = DEFAULT_WIDGET_CONFIG) => {
  const normalizedConfig = normalizeWidgetConfig(config);
  const record = asRecord(body) || {};
  const automation = asRecord(record.automation) || {};
  const status = stringValue(automation.status);
  const publicSessionId =
    stringValue(record.public_session_id) ||
    stringValue(asRecord(record.session)?.public_session_id) ||
    stringValue(record.publicSessionId);

  if (status === 'replied') {
    const reply = asRecord(automation.reply) || asRecord(record.reply) || {};
    const replyText =
      stringValue(reply.text) || stringValue(reply.body) || stringValue(automation.text);

    return {
      status: replyText ? 'replied' : 'fallback',
      publicSessionId,
      replyText: replyText || '',
      systemText: replyText ? '' : normalizedConfig.fallbackMessage,
      reason: stringValue(automation.reason),
      raw: body,
    };
  }

  if (status === 'disabled') {
    return {
      status: 'disabled',
      publicSessionId,
      replyText: '',
      systemText:
        stringValue(automation.message) ||
        stringValue(asRecord(automation.reply)?.text) ||
        normalizedConfig.disabledMessage,
      reason: stringValue(automation.reason),
      raw: body,
    };
  }

  if (status === 'fallback') {
    return {
      status: 'fallback',
      publicSessionId,
      replyText: '',
      systemText:
        stringValue(automation.message) ||
        stringValue(asRecord(automation.reply)?.text) ||
        normalizedConfig.fallbackMessage,
      reason: stringValue(automation.reason),
      raw: body,
    };
  }

  return {
    status: 'fallback',
    publicSessionId,
    replyText: '',
    systemText: normalizedConfig.fallbackMessage,
    reason: '',
    raw: body,
  };
};

const parseUtm = (search) => {
  const value = stringValue(search);
  if (!value) return undefined;

  const params = new URLSearchParams(value.startsWith('?') ? value.slice(1) : value);
  const utm = compactRecord({
    source: params.get('utm_source') || undefined,
    medium: params.get('utm_medium') || undefined,
    campaign: params.get('utm_campaign') || undefined,
    term: params.get('utm_term') || undefined,
    content: params.get('utm_content') || undefined,
  });

  return Object.keys(utm).length > 0 ? utm : undefined;
};

const parseQuickReplies = (value) => {
  const trimmed = stringValue(value).trim();
  if (!trimmed) return [];
  const parsed = parseJson(trimmed);
  if (Array.isArray(parsed)) return normalizeQuickReplies(parsed);
  return normalizeQuickReplies(
    trimmed
      .split('|')
      .map((label) => ({ label: label.trim(), value: label.trim() }))
      .filter((reply) => reply.label),
  );
};

const parseMobileActions = (value) => {
  const trimmed = stringValue(value).trim();
  if (!trimmed) return [];
  const parsed = parseJson(trimmed);
  if (Array.isArray(parsed)) return normalizeMobileActions(parsed);
  return normalizeMobileActions(
    trimmed
      .split('|')
      .map((label, index) => ({ id: `action-${index + 1}`, label: label.trim() }))
      .filter((action) => action.label),
  );
};

const normalizeQuickReplies = (value) => {
  const items = Array.isArray(value) ? value : [];
  return items
    .map((reply) => ({
      label: stringValue(reply?.label).trim(),
      value: stringValue(reply?.value || reply?.label).trim(),
    }))
    .filter((reply) => reply.label && reply.value)
    .slice(0, 6);
};

const normalizeMobileActions = (value) => {
  const items = Array.isArray(value) ? value : [];
  return items
    .map((action) => ({
      id: stringValue(action?.id).trim(),
      label: stringValue(action?.label).trim(),
      icon: stringValue(action?.icon || action?.id).trim(),
      href: stringValue(action?.href).trim(),
      value: stringValue(action?.value).trim(),
    }))
    .filter((action) => action.id && action.label)
    .slice(0, 4);
};

const createClientId = (prefix = 'id') => `${prefix}_${randomToken()}`;

const createPublicSessionId = (prefix = 'sws') => `${prefix}_${randomToken()}`;

const createIdempotencyKey = (publicSessionId) =>
  `site-widget:${stringValue(publicSessionId)}:${Date.now()}:${randomToken()}`;

const randomToken = () => {
  const cryptoApi = globalThis.crypto;
  if (cryptoApi && typeof cryptoApi.randomUUID === 'function') {
    return cryptoApi.randomUUID().replaceAll('-', '');
  }

  const bytes = new Uint8Array(16);
  if (cryptoApi && typeof cryptoApi.getRandomValues === 'function') {
    cryptoApi.getRandomValues(bytes);
    return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  return `${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
};

const compactRecord = (record) => {
  const result = {};
  if (!record || typeof record !== 'object') return result;
  for (const [key, value] of Object.entries(record)) {
    if (value === undefined || value === null || value === '') continue;
    if (typeof value === 'object' && !Array.isArray(value)) {
      if (Object.keys(value).length === 0) continue;
    }
    result[key] = value;
  }
  return result;
};

const asRecord = (value) => {
  if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  return null;
};

const stringValue = (value) => {
  if (value === undefined || value === null) return '';
  return String(value).trim();
};

const normalizePosition = (value) => {
  const position = stringValue(value);
  if (position === 'bottom-left' || position === 'inline') return position;
  return 'bottom-right';
};

const parseBooleanAttribute = (value) => {
  const normalized = stringValue(value).toLowerCase();
  return normalized === '' || normalized === '1' || normalized === 'true' || normalized === 'yes';
};

const setAttributeIfValue = (element, name, value) => {
  if (value !== undefined && value !== null && String(value).length > 0) {
    element.setAttribute(name, String(value));
  }
};

const trimTrailingSlash = (value) => value.replace(/\/+$/, '');

const parseJson = (value) => {
  try {
    return JSON.parse(value);
  } catch {
    return undefined;
  }
};

const clearErrorStatuses = (messages) =>
  messages.map((message) => ({
    ...message,
    status: message.status === 'error' ? 'sent' : message.status,
  }));

const finishSubmit = (state) => ({
  ...state,
  submitting: false,
  pending: null,
});

export {
  ATTRIBUTE_MAP,
  DEFAULT_MOBILE_ACTIONS,
  DEFAULT_QUICK_REPLIES,
  DEFAULT_WIDGET_CONFIG,
  EVENT_TYPE_MESSAGE_SUBMITTED,
  OBSERVED_ATTRIBUTES,
  SCHEMA_VERSION,
  applyOptionsToElement,
  applyWidgetAction,
  buildSiteWidgetMessageRequest,
  buildWidgetState,
  buildWidgetViewModel,
  createClientId,
  createIdempotencyKey,
  createPublicSessionId,
  createWidgetMessage,
  createWidgetState,
  mapSiteWidgetResponse,
  normalizeMobileActions,
  normalizeQuickReplies,
  normalizeWidgetConfig,
  parseMobileActions,
  parseQuickReplies,
  parseUtm,
  readConfigFromElement,
  validateDraft,
};
