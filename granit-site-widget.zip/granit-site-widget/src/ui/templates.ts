import type { SiteWidgetConfig, SiteWidgetMobileAction, WidgetMessage } from "../types/public.js";
import type { WidgetControllerSnapshot } from "../core/widget-controller.js";

export function renderWidget(config: SiteWidgetConfig, state: WidgetControllerSnapshot): string {
  return `
    <div class="sw-root" data-open="${state.open ? "true" : "false"}">
      ${state.open ? renderPanel(config, state) : renderClosed(config)}
    </div>
  `;
}

function renderClosed(config: SiteWidgetConfig): string {
  return `
    <button class="sw-launcher" part="launcher" type="button" data-action="open" aria-haspopup="dialog" aria-expanded="false">
      <span class="sw-launcher-icon" aria-hidden="true">${icon("message")}</span>
      <span class="sw-launcher-label">${escapeHtml(config.launcherLabel)}</span>
    </button>
    ${renderMobileActions(config)}
  `;
}

function renderPanel(config: SiteWidgetConfig, state: WidgetControllerSnapshot): string {
  return `
    <section class="sw-panel" part="panel" role="dialog" aria-modal="false" aria-label="${escapeHtml(config.headerTitle)}">
      <header class="sw-header" part="header">
        <div class="sw-brand" part="brand" aria-hidden="true">${icon("brand")}</div>
        <div>
          <h2 class="sw-title" part="header-title">${escapeHtml(config.headerTitle)}</h2>
          <div class="sw-status-line" part="status-line">
            <span class="sw-status-dot" aria-hidden="true"></span>
            <span>${escapeHtml(config.headerStatus)}</span>
            <span aria-hidden="true">·</span>
            <span>${escapeHtml(config.headerResponseTime)}</span>
          </div>
        </div>
        <button class="sw-icon-button" part="minimize-button" type="button" data-action="close" aria-label="${escapeHtml(config.minimizeLabel)}">${icon("minus")}</button>
        <button class="sw-icon-button" part="close-button" type="button" data-action="close" aria-label="${escapeHtml(config.closeLabel)}">${icon("close")}</button>
      </header>

      <div class="sw-body" part="body">
        <div class="sw-log" part="message-list" role="log" aria-live="polite" aria-relevant="additions">
          ${state.messages.map((message) => renderMessage(message, config)).join("")}
        </div>

        ${renderQuickReplies(config, state)}
      </div>

      <div class="sw-composer-shell" part="composer-shell">
        ${renderComposer(config, state)}
        ${renderContactCapture(config, state)}
        <div class="sw-footer-note" part="footer-note">
          <span aria-hidden="true">${icon("shield")}</span>
          <span>${escapeHtml(config.footerNote)}</span>
        </div>
      </div>
    </section>
  `;
}

function renderMessage(message: WidgetMessage, config: SiteWidgetConfig): string {
  const roleClass = `sw-message-${message.role}`;
  const statusClass = message.status === "error" ? " sw-message-error" : "";
  const part = `message message-${message.role}`;

  return `
    <article class="sw-message ${roleClass}${statusClass}" part="${part}" data-message-id="${escapeHtml(message.id)}">
      <p>${formatText(message.text)}</p>
      ${message.disclosure ? `<div class="sw-disclosure" part="disclosure"><span aria-hidden="true">${icon("spark")}</span><span>${escapeHtml(config.disclosureText)}</span></div>` : ""}
      ${message.status === "pending" ? `<small>${escapeHtml("отправляем...")}</small>` : ""}
      ${message.status === "error" ? `<small>${escapeHtml("ошибка отправки")}</small>` : ""}
    </article>
  `;
}

function renderQuickReplies(config: SiteWidgetConfig, state: WidgetControllerSnapshot): string {
  if (state.submitting || config.quickReplies.length === 0) return "";

  return `
    <div class="sw-quick-replies" part="quick-replies">
      ${config.quickReplies
        .map(
          (reply) => `
            <button class="sw-quick-reply" part="quick-reply" type="button" data-action="quick-reply" data-value="${escapeAttribute(reply.value ?? reply.label)}">
              ${escapeHtml(reply.label)}
            </button>
          `
        )
        .join("")}
    </div>
  `;
}

function renderComposer(config: SiteWidgetConfig, state: WidgetControllerSnapshot): string {
  const disabled = state.submitting ? "disabled" : "";
  const canSend = state.draft.trim().length > 0 && !state.submitting;

  return `
    <form class="sw-composer" part="composer" data-action="submit-message">
      <button class="sw-attach" part="attach-button" type="button" disabled aria-label="${escapeHtml(config.attachLabel)}">
        <span class="sw-attach-icon" aria-hidden="true">${icon("paperclip")}</span>
      </button>
      <label class="sw-visually-hidden" for="sw-message-input">${escapeHtml(config.placeholder)}</label>
      <textarea class="sw-input" part="input" id="sw-message-input" rows="1" ${disabled} placeholder="${escapeAttribute(config.placeholder)}">${escapeHtml(state.draft)}</textarea>
      <button class="sw-send" part="send-button" type="submit" ${canSend ? "" : "disabled"} aria-label="${escapeHtml(config.sendLabel)}">
        ${state.submitting ? icon("loader") : icon("send")}
      </button>
    </form>
    ${state.pending && !state.submitting ? `<button class="sw-retry" part="retry-button" type="button" data-action="retry">${escapeHtml(config.retryLabel)}</button>` : ""}
  `;
}

function renderContactCapture(config: SiteWidgetConfig, state: WidgetControllerSnapshot): string {
  return `
    <div class="sw-contact-row" part="contact-row">
      <button class="sw-contact-trigger" part="phone-trigger" type="button" data-action="toggle-phone">
        <span aria-hidden="true">+</span>
        <span>${escapeHtml(state.contactPhone ? config.phoneSavedLabel : config.phoneCaptureLabel)}</span>
      </button>
    </div>
    ${
      state.contactCaptureOpen
        ? `
          <div class="sw-contact-capture" part="phone-capture">
            <label class="sw-visually-hidden" for="sw-phone-input">${escapeHtml(config.phoneCaptureLabel)}</label>
            <input class="sw-phone-input" part="phone-input" id="sw-phone-input" inputmode="tel" autocomplete="tel" value="${escapeAttribute(state.contactPhone)}" placeholder="+7 999 000-00-00" />
            <button class="sw-phone-save" part="phone-save-button" type="button" data-action="save-phone">OK</button>
          </div>
        `
        : ""
    }
  `;
}

function renderMobileActions(config: SiteWidgetConfig): string {
  if (config.mobileActions.length === 0) return "";

  return `
    <nav class="sw-mobile-actions" part="mobile-actions" aria-label="Быстрые действия">
      ${config.mobileActions.map((action) => renderMobileAction(action, config)).join("")}
    </nav>
  `;
}

function renderMobileAction(action: SiteWidgetMobileAction, config: SiteWidgetConfig): string {
  const actionIcon = icon(action.icon ?? action.id);
  const label = escapeHtml(action.label);

  if (action.id === "call") {
    const href = action.href ?? config.phoneHref;
    if (href) {
      return `<a class="sw-mobile-action" part="mobile-action mobile-action-call" href="${escapeAttribute(href)}"><span class="sw-mobile-icon" aria-hidden="true">${actionIcon}</span><span>${label}</span></a>`;
    }
  }

  return `
    <button class="sw-mobile-action" part="mobile-action mobile-action-${escapeAttribute(action.id)}" type="button" data-action="mobile-action" data-mobile-action="${escapeAttribute(action.id)}" data-value="${escapeAttribute(action.value ?? "")}">
      <span class="sw-mobile-icon" aria-hidden="true">${actionIcon}</span><span>${label}</span>
    </button>
  `;
}

function icon(name: string): string {
  switch (name) {
    case "message":
      return `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a7.5 7.5 0 0 1-7.5 7.5H8l-5 2 1.6-4.4A7.5 7.5 0 1 1 21 12Z"/><path d="M8 11.5h8M8 14.5h5"/></svg>`;
    case "brand":
      return `<svg viewBox="0 0 32 32" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 23h22L19 9l-4.5 8-3-4.8L5 23Z"/><path d="M19 9l3 14"/></svg>`;
    case "minus":
      return `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 12h12"/></svg>`;
    case "close":
      return `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>`;
    case "paperclip":
      return `<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m21 8.5-9.7 9.7a5 5 0 0 1-7.1-7.1l10-10a3.2 3.2 0 0 1 4.5 4.5L8.6 15.7a1.5 1.5 0 0 1-2.1-2.1L15.8 4.3"/></svg>`;
    case "send":
      return `<svg viewBox="0 0 24 24" width="21" height="21" fill="currentColor"><path d="M3.7 20.3 21 3l-6.1 18.2-3.6-8.5-7.6 7.6Zm8.7-8.7 3.4 3.4 2.3-6.8-5.7 3.4Z"/></svg>`;
    case "loader":
      return `<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3a9 9 0 1 0 9 9"/></svg>`;
    case "shield":
      return `<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-5"/></svg>`;
    case "phone":
      return `<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3 5.2 2 2 0 0 1 5 3h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.4 2.1L8 11.6a16 16 0 0 0 4.4 4.4l2.2-2.2a2 2 0 0 1 2.1-.4c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2Z"/></svg>`;
    case "calculator":
      return `<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><path d="M8 6h8M8 11h2M12 11h2M16 11h.01M8 15h2M12 15h2M16 15h.01M8 19h2M12 19h2M16 19h.01"/></svg>`;
    case "spark":
      return `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v5M12 17v5M4.9 4.9l3.5 3.5M15.6 15.6l3.5 3.5M2 12h5M17 12h5M4.9 19.1l3.5-3.5M15.6 8.4l3.5-3.5"/></svg>`;
    default:
      return icon("message");
  }
}

function formatText(value: string): string {
  return escapeHtml(value).replace(/\n/g, "<br />");
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttribute(value: string): string {
  return escapeHtml(value).replace(/`/g, "&#096;");
}
