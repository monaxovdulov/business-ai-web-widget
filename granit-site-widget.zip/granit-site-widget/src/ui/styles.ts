export const WIDGET_STYLES = `
:host {
  --sw-color-accent: #9d8062;
  --sw-color-accent-text: #ffffff;
  --sw-color-surface-panel: #fbf8f4;
  --sw-color-surface-raised: #ffffff;
  --sw-color-surface-visitor: #efe2d5;
  --sw-color-surface-system: #f5efe8;
  --sw-color-text-primary: #29241f;
  --sw-color-text-secondary: #746c64;
  --sw-color-border: rgba(52, 44, 36, 0.12);
  --sw-color-success: #5ebc55;
  --sw-radius-panel: 28px;
  --sw-radius-bubble: 16px;
  --sw-radius-button: 999px;
  --sw-shadow-panel: 0 28px 90px rgba(35, 29, 22, 0.18);
  --sw-shadow-launcher: 0 14px 38px rgba(81, 62, 45, 0.25);
  --sw-font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  --sw-position-right: 28px;
  --sw-position-left: auto;
  --sw-position-bottom: 28px;
  --sw-panel-width: 408px;
  --sw-panel-max-height: min(720px, calc(100vh - 56px));
  --sw-z-index: 2147483000;

  position: fixed;
  right: var(--sw-position-right);
  left: var(--sw-position-left);
  bottom: var(--sw-position-bottom);
  z-index: var(--sw-z-index);
  display: block;
  color: var(--sw-color-text-primary);
  font-family: var(--sw-font-family);
  line-height: 1.4;
  text-align: left;
  box-sizing: border-box;
}

:host([position="bottom-left"]) {
  --sw-position-right: auto;
  --sw-position-left: 28px;
}

:host([position="inline"]) {
  position: relative;
  right: auto;
  left: auto;
  bottom: auto;
  z-index: auto;
  display: inline-block;
}

:host([theme="neutral"]) {
  --sw-color-accent: #4f5965;
  --sw-color-surface-panel: #f8f9fa;
  --sw-color-surface-visitor: #edf0f3;
}

:host([theme="contrast"]) {
  --sw-color-accent: #1f2937;
  --sw-color-surface-panel: #ffffff;
  --sw-color-surface-visitor: #e5e7eb;
  --sw-color-text-primary: #111827;
  --sw-color-text-secondary: #4b5563;
}

* { box-sizing: border-box; }
button, input, textarea { font: inherit; }
button { color: inherit; }

.sw-root {
  width: max-content;
  max-width: calc(100vw - 32px);
}

.sw-launcher {
  align-items: center;
  background: linear-gradient(180deg, color-mix(in srgb, var(--sw-color-accent) 84%, white), var(--sw-color-accent));
  border: 1px solid color-mix(in srgb, var(--sw-color-accent) 70%, white);
  border-radius: var(--sw-radius-button);
  box-shadow: var(--sw-shadow-launcher);
  color: var(--sw-color-accent-text);
  cursor: pointer;
  display: inline-flex;
  gap: 12px;
  min-height: 58px;
  padding: 0 26px;
  transition: transform 160ms ease, box-shadow 160ms ease, opacity 160ms ease;
}

.sw-launcher:hover { transform: translateY(-1px); }
.sw-launcher:active { transform: translateY(0); }
.sw-launcher:focus-visible,
.sw-icon-button:focus-visible,
.sw-quick-reply:focus-visible,
.sw-send:focus-visible,
.sw-mobile-action:focus-visible,
.sw-contact-trigger:focus-visible,
.sw-phone-save:focus-visible,
.sw-retry:focus-visible {
  outline: 3px solid color-mix(in srgb, var(--sw-color-accent) 35%, white);
  outline-offset: 3px;
}

.sw-launcher-icon,
.sw-mobile-icon,
.sw-attach-icon {
  display: inline-flex;
  width: 22px;
  height: 22px;
  align-items: center;
  justify-content: center;
}

.sw-launcher-label { font-size: 17px; font-weight: 580; }

.sw-panel {
  background: color-mix(in srgb, var(--sw-color-surface-panel) 94%, transparent);
  border: 1px solid var(--sw-color-border);
  border-radius: var(--sw-radius-panel);
  box-shadow: var(--sw-shadow-panel);
  display: flex;
  flex-direction: column;
  max-height: var(--sw-panel-max-height);
  overflow: hidden;
  width: min(var(--sw-panel-width), calc(100vw - 32px));
  backdrop-filter: blur(12px);
  animation: sw-panel-in 170ms ease-out;
}

@keyframes sw-panel-in {
  from { opacity: 0; transform: translateY(12px) scale(0.985); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}

.sw-header {
  align-items: center;
  border-bottom: 1px solid var(--sw-color-border);
  display: grid;
  gap: 14px;
  grid-template-columns: 48px 1fr auto auto;
  padding: 20px 22px;
}

.sw-brand {
  align-items: center;
  background: var(--sw-color-surface-raised);
  border: 1px solid var(--sw-color-border);
  border-radius: 50%;
  box-shadow: 0 8px 24px rgba(35, 29, 22, 0.08);
  display: inline-flex;
  height: 48px;
  justify-content: center;
  width: 48px;
}

.sw-title {
  font-size: 20px;
  font-weight: 680;
  margin: 0;
}

.sw-status-line {
  align-items: center;
  color: var(--sw-color-text-secondary);
  display: flex;
  flex-wrap: wrap;
  font-size: 13px;
  gap: 7px;
  margin-top: 2px;
}

.sw-status-dot {
  background: var(--sw-color-success);
  border-radius: 50%;
  display: inline-block;
  height: 9px;
  width: 9px;
}

.sw-icon-button {
  align-items: center;
  background: var(--sw-color-surface-raised);
  border: 1px solid var(--sw-color-border);
  border-radius: 50%;
  cursor: pointer;
  display: inline-flex;
  height: 38px;
  justify-content: center;
  padding: 0;
  transition: transform 140ms ease, background 140ms ease;
  width: 38px;
}

.sw-icon-button:hover { background: color-mix(in srgb, var(--sw-color-surface-raised) 80%, var(--sw-color-accent)); }
.sw-icon-button:active { transform: scale(0.97); }

.sw-body {
  display: flex;
  flex-direction: column;
  gap: 14px;
  overflow: auto;
  padding: 22px;
  scroll-behavior: smooth;
}

.sw-log {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.sw-message {
  border: 1px solid var(--sw-color-border);
  border-radius: var(--sw-radius-bubble);
  box-shadow: 0 10px 30px rgba(35, 29, 22, 0.05);
  font-size: 15px;
  max-width: 86%;
  padding: 15px 16px 13px;
  position: relative;
  white-space: normal;
}

.sw-message p { margin: 0; }
.sw-message small {
  color: var(--sw-color-text-secondary);
  display: block;
  font-size: 11px;
  margin-top: 8px;
  text-align: right;
}

.sw-message-assistant {
  align-self: flex-start;
  background: var(--sw-color-surface-raised);
}

.sw-message-visitor {
  align-self: flex-end;
  background: var(--sw-color-surface-visitor);
}

.sw-message-system {
  align-self: center;
  background: var(--sw-color-surface-system);
  color: var(--sw-color-text-secondary);
  max-width: 94%;
}

.sw-message-error {
  border-color: color-mix(in srgb, #b42318 35%, var(--sw-color-border));
}

.sw-disclosure {
  align-items: center;
  color: var(--sw-color-text-secondary);
  display: flex;
  font-size: 12px;
  gap: 6px;
  margin-top: 10px;
}

.sw-quick-replies {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.sw-quick-reply {
  background: color-mix(in srgb, var(--sw-color-surface-raised) 86%, transparent);
  border: 1px solid var(--sw-color-border);
  border-radius: var(--sw-radius-button);
  cursor: pointer;
  min-height: 44px;
  padding: 0 18px;
}

.sw-quick-reply:hover { border-color: color-mix(in srgb, var(--sw-color-accent) 45%, var(--sw-color-border)); }

.sw-composer-shell {
  border-top: 1px solid var(--sw-color-border);
  padding: 0 22px 20px;
}

.sw-composer {
  align-items: center;
  background: var(--sw-color-surface-raised);
  border: 1px solid var(--sw-color-border);
  border-radius: var(--sw-radius-button);
  display: grid;
  gap: 10px;
  grid-template-columns: 38px 1fr 44px;
  min-height: 58px;
  padding: 7px 8px 7px 12px;
}

.sw-attach {
  align-items: center;
  background: transparent;
  border: 0;
  border-radius: 50%;
  color: var(--sw-color-accent);
  cursor: not-allowed;
  display: inline-flex;
  height: 38px;
  justify-content: center;
  opacity: 0.6;
  padding: 0;
  width: 38px;
}

.sw-input {
  background: transparent;
  border: 0;
  color: var(--sw-color-text-primary);
  min-height: 38px;
  max-height: 120px;
  outline: 0;
  padding: 9px 0;
  resize: none;
  width: 100%;
}

.sw-input::placeholder { color: color-mix(in srgb, var(--sw-color-text-secondary) 62%, transparent); }

.sw-send {
  align-items: center;
  background: var(--sw-color-accent);
  border: 0;
  border-radius: 50%;
  color: var(--sw-color-accent-text);
  cursor: pointer;
  display: inline-flex;
  height: 44px;
  justify-content: center;
  padding: 0;
  transition: opacity 140ms ease, transform 140ms ease;
  width: 44px;
}

.sw-send:disabled {
  cursor: not-allowed;
  opacity: 0.45;
}

.sw-send:not(:disabled):active { transform: scale(0.97); }

.sw-contact-row {
  align-items: center;
  display: flex;
  gap: 10px;
  margin-top: 14px;
}

.sw-contact-trigger {
  align-items: center;
  background: transparent;
  border: 0;
  border-radius: 10px;
  color: var(--sw-color-accent);
  cursor: pointer;
  display: inline-flex;
  gap: 10px;
  padding: 8px 0;
}

.sw-contact-capture {
  display: grid;
  gap: 10px;
  grid-template-columns: 1fr auto;
  margin-top: 8px;
}

.sw-phone-input {
  background: var(--sw-color-surface-raised);
  border: 1px solid var(--sw-color-border);
  border-radius: 14px;
  min-height: 42px;
  outline: 0;
  padding: 0 12px;
}

.sw-phone-save, .sw-retry {
  background: var(--sw-color-accent);
  border: 0;
  border-radius: var(--sw-radius-button);
  color: var(--sw-color-accent-text);
  cursor: pointer;
  min-height: 42px;
  padding: 0 16px;
}

.sw-footer-note {
  align-items: flex-start;
  border-top: 1px solid var(--sw-color-border);
  color: var(--sw-color-text-secondary);
  display: flex;
  font-size: 13px;
  gap: 10px;
  margin-top: 14px;
  padding-top: 14px;
}

.sw-mobile-actions {
  display: none;
}

.sw-visually-hidden {
  border: 0;
  clip: rect(0 0 0 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  white-space: nowrap;
  width: 1px;
}

@media (max-width: 640px) {
  :host {
    --sw-position-right: 12px;
    --sw-position-left: 12px;
    --sw-position-bottom: 12px;
    width: auto;
  }

  :host([position="bottom-left"]) {
    --sw-position-right: 12px;
    --sw-position-left: 12px;
  }

  .sw-root { width: 100%; max-width: none; }
  .sw-launcher { min-height: 54px; padding: 0 22px; }
  .sw-panel {
    border-radius: 24px;
    max-height: calc(100vh - 24px);
    width: 100%;
  }

  .sw-header {
    grid-template-columns: 44px 1fr auto auto;
    padding: 16px;
  }

  .sw-title { font-size: 18px; }
  .sw-body { padding: 16px; }
  .sw-message { max-width: 92%; }
  .sw-composer-shell { padding: 0 16px 16px; }

  .sw-mobile-actions {
    background: color-mix(in srgb, var(--sw-color-surface-raised) 94%, transparent);
    border: 1px solid var(--sw-color-border);
    border-radius: 22px;
    box-shadow: var(--sw-shadow-panel);
    display: grid;
    gap: 0;
    grid-template-columns: repeat(3, 1fr);
    margin-top: 12px;
    overflow: hidden;
    width: 100%;
  }

  .sw-mobile-action {
    align-items: center;
    background: transparent;
    border: 0;
    border-right: 1px solid var(--sw-color-border);
    cursor: pointer;
    display: inline-flex;
    gap: 8px;
    justify-content: center;
    min-height: 64px;
    padding: 0 10px;
    text-decoration: none;
  }

  .sw-mobile-action:last-child { border-right: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .sw-panel { animation: none; }
  .sw-launcher, .sw-send, .sw-icon-button { transition: none; }
}
`;
