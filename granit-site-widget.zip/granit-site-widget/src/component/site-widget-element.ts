import { OBSERVED_CONFIG_ATTRIBUTES, readConfigFromElement } from "../config/config-schema.js";
import { createIdempotencyKey } from "../core/idempotency.js";
import { sendSiteWidgetMessage } from "../core/intake-client.js";
import { createSessionStore, type SessionStore } from "../core/session-store.js";
import { buildSiteWidgetMessageRequest } from "../core/site-widget-request.js";
import { WidgetController } from "../core/widget-controller.js";
import { emitWidgetEvent } from "../core/events.js";
import type { SiteWidgetConfig, SiteWidgetContact } from "../types/public.js";
import { WIDGET_STYLES } from "../ui/styles.js";
import { renderWidget } from "../ui/templates.js";

export const SITE_WIDGET_TAG_NAME = "granit-site-widget";

const HTMLElementBase: typeof HTMLElement =
  typeof HTMLElement === "undefined" ? (class {} as typeof HTMLElement) : HTMLElement;

export class GranitSiteWidgetElement extends HTMLElementBase {
  static observedAttributes = ["open", ...OBSERVED_CONFIG_ATTRIBUTES];

  private config!: SiteWidgetConfig;
  private controller!: WidgetController;
  private sessionStore!: SessionStore;
  private publicSessionId = "";
  private abortController?: AbortController;
  private initialized = false;
  private renderQueued = false;

  constructor() {
    super();
    if (typeof this.attachShadow === "function") {
      this.attachShadow({ mode: "open" });
    }
  }

  connectedCallback(): void {
    this.boot();
  }

  disconnectedCallback(): void {
    this.abortController?.abort();
  }

  attributeChangedCallback(): void {
    if (!this.initialized) return;
    this.config = readConfigFromElement(this);
    if (this.hasAttribute("open")) this.controller.open();
    else this.controller.close();
    this.syncHostAttributes();
    this.render();
  }

  open(): void {
    this.ensureBooted();
    this.controller.open();
    this.setAttribute("open", "");
    emitWidgetEvent(this, "open", { widgetInstanceId: this.config.widgetInstanceId });
    this.render();
    this.focusInputSoon();
  }

  close(): void {
    this.ensureBooted();
    this.controller.close();
    this.removeAttribute("open");
    emitWidgetEvent(this, "close", { widgetInstanceId: this.config.widgetInstanceId });
    this.render();
  }

  sendMessage(text: string): void {
    this.ensureBooted();
    const normalized = text.trim();
    if (!normalized) return;
    this.controller.setDraft(normalized);
    void this.submitDraft();
  }

  private boot(): void {
    if (this.initialized) return;

    this.config = readConfigFromElement(this);
    this.syncHostAttributes();
    this.controller = new WidgetController(this.config.introMessage, this.hasAttribute("open"));
    this.sessionStore = createSessionStore(this.config.widgetInstanceId);
    this.publicSessionId = this.sessionStore.get();
    this.initialized = true;

    this.render();
    emitWidgetEvent(this, "ready", { widgetInstanceId: this.config.widgetInstanceId });
  }

  private ensureBooted(): void {
    if (!this.initialized) this.boot();
  }


  private syncHostAttributes(): void {
    if (this.getAttribute("theme") !== this.config.theme) {
      this.setAttribute("theme", this.config.theme);
    }
    if (this.getAttribute("position") !== this.config.position) {
      this.setAttribute("position", this.config.position);
    }
  }

  private render(): void {
    if (!this.shadowRoot) return;
    const snapshot = this.controller.snapshot();
    this.shadowRoot.innerHTML = `<style>${WIDGET_STYLES}</style>${renderWidget(this.config, snapshot)}`;
    this.bindEvents();
    this.scrollLogToBottom();
  }

  private queueRender(): void {
    if (this.renderQueued) return;
    this.renderQueued = true;
    queueMicrotask(() => {
      this.renderQueued = false;
      this.render();
    });
  }

  private bindEvents(): void {
    if (!this.shadowRoot) return;

    this.shadowRoot.querySelectorAll<HTMLElement>("[data-action]").forEach((element) => {
      const action = element.dataset.action;
      if (action === "open") element.addEventListener("click", () => this.open());
      if (action === "close") element.addEventListener("click", () => this.close());
      if (action === "quick-reply") element.addEventListener("click", () => this.handleQuickReply(element));
      if (action === "mobile-action") element.addEventListener("click", () => this.handleMobileAction(element));
      if (action === "toggle-phone") element.addEventListener("click", () => this.togglePhoneCapture());
      if (action === "save-phone") element.addEventListener("click", () => this.savePhone());
      if (action === "retry") element.addEventListener("click", () => void this.retryPending());
    });

    const form = this.shadowRoot.querySelector<HTMLFormElement>('[data-action="submit-message"]');
    form?.addEventListener("submit", (event) => {
      event.preventDefault();
      void this.submitDraft();
    });

    const textarea = this.shadowRoot.querySelector<HTMLTextAreaElement>(".sw-input");
    textarea?.addEventListener("input", () => {
      this.controller.setDraft(textarea.value);
      this.autoGrowTextarea(textarea);
      const sendButton = this.shadowRoot?.querySelector<HTMLButtonElement>(".sw-send");
      if (sendButton) sendButton.disabled = textarea.value.trim().length === 0 || this.controller.snapshot().submitting;
    });
    textarea?.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        void this.submitDraft();
      }
      if (event.key === "Escape") {
        event.preventDefault();
        this.close();
      }
    });

    const phoneInput = this.shadowRoot.querySelector<HTMLInputElement>(".sw-phone-input");
    phoneInput?.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        this.savePhone();
      }
    });
  }

  private handleQuickReply(element: HTMLElement): void {
    const value = element.dataset.value ?? element.textContent ?? "";
    this.controller.setDraft(value);
    void this.submitDraft();
  }

  private handleMobileAction(element: HTMLElement): void {
    const id = element.dataset.mobileAction;
    const value = element.dataset.value ?? "";

    if (id === "message") {
      this.open();
      return;
    }

    if (id === "calculation") {
      this.open();
      this.controller.setDraft(value || "Нужен расчет памятника");
      this.render();
      this.focusInputSoon();
      return;
    }

    this.open();
  }

  private togglePhoneCapture(): void {
    this.controller.toggleContactCapture();
    this.render();
    this.shadowRoot?.querySelector<HTMLInputElement>(".sw-phone-input")?.focus();
  }

  private savePhone(): void {
    const phoneInput = this.shadowRoot?.querySelector<HTMLInputElement>(".sw-phone-input");
    const value = phoneInput?.value.trim() ?? "";
    this.controller.setContactPhone(value);
    this.controller.toggleContactCapture(false);
    emitWidgetEvent(this, "phone-saved", {
      widgetInstanceId: this.config.widgetInstanceId,
      hasPhone: value.length > 0
    });
    this.render();
  }

  private async submitDraft(): Promise<void> {
    const snapshot = this.controller.snapshot();
    const text = snapshot.draft.trim();
    if (!text || snapshot.submitting) return;

    const idempotencyKey = createIdempotencyKey(this.publicSessionId);
    this.controller.beginSubmit(text, idempotencyKey);
    this.render();
    await this.sendPending(text, idempotencyKey);
  }

  private async retryPending(): Promise<void> {
    const pending = this.controller.snapshot().pending;
    if (!pending) return;
    this.controller.beginRetry();
    this.render();
    await this.sendPending(pending.text, pending.idempotencyKey);
  }

  private async sendPending(text: string, idempotencyKey: string): Promise<void> {
    this.abortController?.abort();
    this.abortController = new AbortController();

    try {
      const contact = this.buildContact();
      const request = buildSiteWidgetMessageRequest({
        config: this.config,
        text,
        publicSessionId: this.publicSessionId,
        idempotencyKey,
        contact
      });

      emitWidgetEvent(this, "message-submitted", {
        widgetInstanceId: this.config.widgetInstanceId,
        idempotencyKey,
        publicSessionId: this.publicSessionId
      });

      const response = await sendSiteWidgetMessage(this.config, request, this.abortController.signal);
      if (response.publicSessionId) {
        this.publicSessionId = response.publicSessionId;
        this.sessionStore.set(response.publicSessionId);
      }

      this.controller.markVisitorSent(text);

      if (response.status === "replied" && response.replyText) {
        this.controller.finishWithAssistant(response.replyText);
      } else {
        this.controller.finishWithSystem(response.systemText ?? this.config.fallbackMessage);
      }

      emitWidgetEvent(this, "response", {
        widgetInstanceId: this.config.widgetInstanceId,
        status: response.status,
        reason: response.reason,
        publicSessionId: this.publicSessionId
      });
      this.render();
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      this.controller.fail(this.config.errorMessage);
      emitWidgetEvent(this, "error", {
        widgetInstanceId: this.config.widgetInstanceId,
        message: error instanceof Error ? error.message : String(error)
      });
      this.render();
    }
  }

  private buildContact(): SiteWidgetContact | undefined {
    const snapshot = this.controller.snapshot();
    if (!snapshot.contactPhone) return undefined;
    return {
      phone: snapshot.contactPhone,
      preferred_contact: "phone"
    };
  }

  private focusInputSoon(): void {
    window.setTimeout(() => this.shadowRoot?.querySelector<HTMLTextAreaElement>(".sw-input")?.focus(), 0);
  }

  private scrollLogToBottom(): void {
    window.setTimeout(() => {
      const body = this.shadowRoot?.querySelector<HTMLElement>(".sw-body");
      if (body) body.scrollTop = body.scrollHeight;
    }, 0);
  }

  private autoGrowTextarea(textarea: HTMLTextAreaElement): void {
    textarea.style.height = "auto";
    textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
  }
}
