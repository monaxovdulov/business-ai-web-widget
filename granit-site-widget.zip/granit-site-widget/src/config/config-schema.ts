import { DEFAULT_WIDGET_CONFIG } from "./default-config.js";
import type {
  MountSiteWidgetOptions,
  SiteWidgetConfig,
  SiteWidgetMobileAction,
  SiteWidgetPosition,
  SiteWidgetQuickReply
} from "../types/public.js";

const ATTRIBUTE_MAP: Record<string, keyof SiteWidgetConfig> = {
  "api-base-url": "apiBaseUrl",
  "widget-instance-id": "widgetInstanceId",
  theme: "theme",
  position: "position",
  mock: "mock",
  "launcher-label": "launcherLabel",
  "header-title": "headerTitle",
  "header-status": "headerStatus",
  "header-response-time": "headerResponseTime",
  "intro-message": "introMessage",
  placeholder: "placeholder",
  "disclosure-text": "disclosureText",
  "footer-note": "footerNote",
  "phone-capture-label": "phoneCaptureLabel",
  "phone-saved-label": "phoneSavedLabel",
  "fallback-message": "fallbackMessage",
  "disabled-message": "disabledMessage",
  "error-message": "errorMessage",
  "retry-label": "retryLabel",
  "send-label": "sendLabel",
  "attach-label": "attachLabel",
  "close-label": "closeLabel",
  "minimize-label": "minimizeLabel",
  "phone-href": "phoneHref",
  "privacy-url": "privacyUrl"
};

export const OBSERVED_CONFIG_ATTRIBUTES = [
  ...Object.keys(ATTRIBUTE_MAP),
  "quick-replies",
  "mobile-actions"
];

export function normalizeWidgetConfig(input: Partial<SiteWidgetConfig> = {}): SiteWidgetConfig {
  const config: SiteWidgetConfig = {
    ...DEFAULT_WIDGET_CONFIG,
    ...input,
    quickReplies: normalizeQuickReplies(input.quickReplies ?? DEFAULT_WIDGET_CONFIG.quickReplies),
    mobileActions: normalizeMobileActions(input.mobileActions ?? DEFAULT_WIDGET_CONFIG.mobileActions)
  };

  config.apiBaseUrl = trimTrailingSlash(config.apiBaseUrl.trim());
  config.widgetInstanceId = String(config.widgetInstanceId || "default").trim() || "default";
  config.position = normalizePosition(config.position);
  config.mock = Boolean(config.mock);

  return config;
}

export function readConfigFromElement(element: Element): SiteWidgetConfig {
  const raw: Partial<SiteWidgetConfig> = {};

  for (const [attributeName, configKey] of Object.entries(ATTRIBUTE_MAP)) {
    if (!element.hasAttribute(attributeName)) continue;

    const value = element.getAttribute(attributeName);
    if (value == null) continue;

    if (configKey === "mock") {
      raw.mock = parseBooleanAttribute(value);
    } else {
      (raw as Record<string, unknown>)[configKey] = value;
    }
  }

  if (element.hasAttribute("quick-replies")) {
    raw.quickReplies = parseQuickReplies(element.getAttribute("quick-replies") ?? "");
  }

  if (element.hasAttribute("mobile-actions")) {
    raw.mobileActions = parseMobileActions(element.getAttribute("mobile-actions") ?? "");
  }

  return normalizeWidgetConfig(raw);
}

export function applyOptionsToElement(element: HTMLElement, options: MountSiteWidgetOptions): void {
  const normalized = normalizeWidgetConfig(options);

  setAttr(element, "api-base-url", normalized.apiBaseUrl);
  setAttr(element, "widget-instance-id", normalized.widgetInstanceId);
  setAttr(element, "theme", normalized.theme);
  setAttr(element, "position", normalized.position);
  setAttr(element, "launcher-label", normalized.launcherLabel);
  setAttr(element, "header-title", normalized.headerTitle);
  setAttr(element, "header-status", normalized.headerStatus);
  setAttr(element, "header-response-time", normalized.headerResponseTime);
  setAttr(element, "intro-message", normalized.introMessage);
  setAttr(element, "placeholder", normalized.placeholder);
  setAttr(element, "phone-href", normalized.phoneHref);
  setAttr(element, "privacy-url", normalized.privacyUrl);

  if (normalized.mock) element.setAttribute("mock", "true");
  if (normalized.quickReplies.length > 0) {
    element.setAttribute("quick-replies", JSON.stringify(normalized.quickReplies));
  }
  if (normalized.mobileActions.length > 0) {
    element.setAttribute("mobile-actions", JSON.stringify(normalized.mobileActions));
  }

  if (options.attributes) {
    for (const [key, value] of Object.entries(options.attributes)) {
      element.setAttribute(key, value);
    }
  }
}

function setAttr(element: HTMLElement, name: string, value: string | undefined): void {
  if (typeof value === "string" && value.length > 0) element.setAttribute(name, value);
}

function parseBooleanAttribute(value: string): boolean {
  const normalized = value.trim().toLowerCase();
  return normalized === "" || normalized === "1" || normalized === "true" || normalized === "yes";
}

function normalizePosition(position: string): SiteWidgetPosition {
  if (position === "bottom-left" || position === "inline") return position;
  return "bottom-right";
}

function trimTrailingSlash(value: string): string {
  return value.replace(/\/+$/, "");
}

function parseQuickReplies(value: string): SiteWidgetQuickReply[] {
  const trimmed = value.trim();
  if (!trimmed) return [];

  const parsed = parseJson<SiteWidgetQuickReply[]>(trimmed);
  if (Array.isArray(parsed)) return normalizeQuickReplies(parsed);

  return trimmed
    .split("|")
    .map((item) => item.trim())
    .filter(Boolean)
    .map((label) => ({ label, value: label }));
}

function parseMobileActions(value: string): SiteWidgetMobileAction[] {
  const trimmed = value.trim();
  if (!trimmed) return [];

  const parsed = parseJson<SiteWidgetMobileAction[]>(trimmed);
  if (Array.isArray(parsed)) return normalizeMobileActions(parsed);

  return trimmed
    .split("|")
    .map((item) => item.trim())
    .filter(Boolean)
    .map((label, index) => ({ id: `action-${index + 1}`, label }));
}

function normalizeQuickReplies(value: readonly SiteWidgetQuickReply[]): SiteWidgetQuickReply[] {
  return value
    .map((reply) => ({
      label: String(reply.label ?? "").trim(),
      value: String(reply.value ?? reply.label ?? "").trim()
    }))
    .filter((reply) => reply.label.length > 0 && reply.value.length > 0)
    .slice(0, 6);
}

function normalizeMobileActions(value: readonly SiteWidgetMobileAction[]): SiteWidgetMobileAction[] {
  return value
    .map((action) => ({
      id: String(action.id ?? "").trim(),
      label: String(action.label ?? "").trim(),
      icon: action.icon ? String(action.icon) : undefined,
      href: action.href ? String(action.href) : undefined,
      value: action.value ? String(action.value) : undefined
    }))
    .filter((action) => action.id.length > 0 && action.label.length > 0)
    .slice(0, 4);
}

function parseJson<T>(value: string): T | undefined {
  try {
    return JSON.parse(value) as T;
  } catch {
    return undefined;
  }
}
