import type { SiteWidgetConfig } from "../types/public.js";

export const DEFAULT_QUICK_REPLIES = [
  { label: "Нужен расчет", value: "Нужен расчет памятника с установкой" },
  { label: "Есть вопрос", value: "Здравствуйте, у меня есть вопрос по заказу" },
  { label: "Хочу каталог", value: "Хочу посмотреть каталог памятников" }
] as const;

export const DEFAULT_MOBILE_ACTIONS = [
  { id: "call", label: "Позвонить", icon: "phone" },
  { id: "message", label: "Написать", icon: "message" },
  { id: "calculation", label: "Расчет", icon: "calculator", value: "Нужен расчет памятника" }
] as const;

export const DEFAULT_WIDGET_CONFIG: SiteWidgetConfig = {
  apiBaseUrl: "",
  widgetInstanceId: "default",
  theme: "memorial-soft",
  position: "bottom-right",
  mock: false,

  launcherLabel: "Написать",
  headerTitle: "Поможем с заказом",
  headerStatus: "Онлайн",
  headerResponseTime: "обычно отвечаем за 2 минуты",
  introMessage:
    "Здравствуйте! 👋\nПодскажем по памятнику, рассчитаем стоимость и оформим заказ дистанционно.\nОпишите задачу или выберите вариант ниже.",
  placeholder: "Напишите сообщение...",
  disclosureText: "Ответ подготовлен автоматически. Менеджер проверит детали при необходимости.",
  footerNote: "Расчет бесплатный. Точную стоимость подтвердит менеджер после уточнения деталей.",
  phoneCaptureLabel: "Добавить телефон для ответа",
  phoneSavedLabel: "Телефон добавлен",
  fallbackMessage: "Заявку получили. Менеджер уточнит детали и ответит вам.",
  disabledMessage: "Заявку получили. Менеджер ответит после проверки.",
  errorMessage: "Сообщение не отправилось. Проверьте связь и повторите.",
  retryLabel: "Повторить",
  sendLabel: "Отправить",
  attachLabel: "Приложить файл",
  closeLabel: "Закрыть",
  minimizeLabel: "Свернуть",

  phoneHref: undefined,
  privacyUrl: undefined,
  quickReplies: [...DEFAULT_QUICK_REPLIES],
  mobileActions: [...DEFAULT_MOBILE_ACTIONS]
};
