export type SiteWidgetTheme = "memorial-soft" | "neutral" | "contrast" | string;

export type SiteWidgetPosition =
  | "bottom-right"
  | "bottom-left"
  | "inline";

export type SiteWidgetQuickReply = {
  label: string;
  value?: string;
};

export type SiteWidgetMobileAction = {
  id: "call" | "message" | "calculation" | string;
  label: string;
  icon?: string;
  href?: string;
  value?: string;
};

export type SiteWidgetConfig = {
  apiBaseUrl: string;
  widgetInstanceId: string;
  theme: SiteWidgetTheme;
  position: SiteWidgetPosition;
  mock: boolean;

  launcherLabel: string;
  headerTitle: string;
  headerStatus: string;
  headerResponseTime: string;
  introMessage: string;
  placeholder: string;
  disclosureText: string;
  footerNote: string;
  phoneCaptureLabel: string;
  phoneSavedLabel: string;
  fallbackMessage: string;
  disabledMessage: string;
  errorMessage: string;
  retryLabel: string;
  sendLabel: string;
  attachLabel: string;
  closeLabel: string;
  minimizeLabel: string;

  phoneHref?: string;
  privacyUrl?: string;
  quickReplies: SiteWidgetQuickReply[];
  mobileActions: SiteWidgetMobileAction[];
};

export type SiteWidgetContact = {
  name?: string;
  phone?: string;
  email?: string;
  preferred_contact?: "phone" | "whatsapp" | "telegram" | "email";
  city?: string;
};

export type SiteWidgetUtm = {
  source?: string;
  medium?: string;
  campaign?: string;
  term?: string;
  content?: string;
};

export type SiteWidgetMessageRequest = {
  schema_version: "site_widget.v1";
  event_type: "site_widget.message_submitted";
  idempotency_key: string;
  submitted_at: string;
  public_session_id?: string;
  source: {
    channel: "site_widget";
    page_url: string;
    widget_instance_id: string;
    page_title?: string;
    referrer_url?: string;
    utm?: SiteWidgetUtm;
  };
  contact?: SiteWidgetContact;
  message: {
    role: "visitor";
    text: string;
  };
  visitor_context?: {
    locale?: string;
    timezone?: string;
  };
  consent?: {
    privacy_policy?: boolean;
  };
};

export type WidgetMessageRole = "assistant" | "visitor" | "system";

export type WidgetMessage = {
  id: string;
  role: WidgetMessageRole;
  text: string;
  createdAt: string;
  status?: "pending" | "sent" | "error";
  disclosure?: boolean;
};

export type SiteWidgetResponseViewModel = {
  status: "replied" | "fallback" | "disabled" | "error";
  publicSessionId?: string;
  replyText?: string;
  systemText?: string;
  reason?: string;
  raw: unknown;
};

export type WidgetEventName =
  | "ready"
  | "open"
  | "close"
  | "message-submitted"
  | "response"
  | "error"
  | "phone-saved";

export type MountSiteWidgetOptions = Partial<SiteWidgetConfig> & {
  target?: Element | null;
  attributes?: Record<string, string>;
};
