import type { SiteWidgetConfig, SiteWidgetContact, SiteWidgetMessageRequest, SiteWidgetUtm } from "../types/public.js";

type BuildRequestInput = {
  config: SiteWidgetConfig;
  text: string;
  publicSessionId: string;
  idempotencyKey: string;
  contact?: SiteWidgetContact;
  privacyPolicyAccepted?: boolean;
};

export function buildSiteWidgetMessageRequest(input: BuildRequestInput): SiteWidgetMessageRequest {
  const now = new Date().toISOString();
  const locationSnapshot = getLocationSnapshot();
  const contact = compactContact(input.contact);
  const utm = parseUtm(locationSnapshot.search);

  return {
    schema_version: "site_widget.v1",
    event_type: "site_widget.message_submitted",
    idempotency_key: input.idempotencyKey,
    submitted_at: now,
    public_session_id: input.publicSessionId,
    source: withoutUndefined({
      channel: "site_widget",
      page_url: locationSnapshot.href,
      widget_instance_id: input.config.widgetInstanceId,
      page_title: getPageTitle(),
      referrer_url: getReferrerUrl(),
      utm
    }),
    contact: contact && Object.keys(contact).length > 0 ? contact : undefined,
    message: {
      role: "visitor",
      text: input.text
    },
    visitor_context: withoutUndefined({
      locale: getLocale(),
      timezone: getTimezone()
    }),
    consent: input.privacyPolicyAccepted ? { privacy_policy: true } : undefined
  };
}

export function parseUtm(search: string): SiteWidgetUtm | undefined {
  if (!search) return undefined;

  const params = new URLSearchParams(search.startsWith("?") ? search.slice(1) : search);
  const utm: SiteWidgetUtm = withoutUndefined({
    source: params.get("utm_source") ?? undefined,
    medium: params.get("utm_medium") ?? undefined,
    campaign: params.get("utm_campaign") ?? undefined,
    term: params.get("utm_term") ?? undefined,
    content: params.get("utm_content") ?? undefined
  });

  return Object.keys(utm).length > 0 ? utm : undefined;
}

function compactContact(contact?: SiteWidgetContact): SiteWidgetContact | undefined {
  if (!contact) return undefined;
  return withoutUndefined({
    name: trim(contact.name),
    phone: trim(contact.phone),
    email: trim(contact.email),
    preferred_contact: contact.preferred_contact,
    city: trim(contact.city)
  });
}

function trim(value?: string): string | undefined {
  const normalized = value?.trim();
  return normalized ? normalized : undefined;
}

function withoutUndefined<T extends Record<string, unknown>>(value: T): T {
  for (const key of Object.keys(value)) {
    if (value[key] === undefined || value[key] === "") delete value[key];
  }
  return value;
}

function getLocationSnapshot(): { href: string; search: string } {
  if (typeof window === "undefined") return { href: "", search: "" };
  return {
    href: window.location.href,
    search: window.location.search
  };
}

function getPageTitle(): string | undefined {
  if (typeof document === "undefined") return undefined;
  return document.title || undefined;
}

function getReferrerUrl(): string | undefined {
  if (typeof document === "undefined") return undefined;
  return document.referrer || undefined;
}

function getLocale(): string | undefined {
  if (typeof navigator === "undefined") return undefined;
  return navigator.language || undefined;
}

function getTimezone(): string | undefined {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  } catch {
    return undefined;
  }
}
