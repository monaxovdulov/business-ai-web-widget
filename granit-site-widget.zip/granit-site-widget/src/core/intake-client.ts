import type { SiteWidgetConfig, SiteWidgetMessageRequest, SiteWidgetResponseViewModel } from "../types/public.js";
import { mapSiteWidgetResponse } from "./response-mapper.js";

export async function sendSiteWidgetMessage(
  config: SiteWidgetConfig,
  request: SiteWidgetMessageRequest,
  signal?: AbortSignal
): Promise<SiteWidgetResponseViewModel> {
  if (config.mock) return mockSiteWidgetMessage(config, request);

  if (!config.apiBaseUrl) {
    throw new Error("apiBaseUrl is required when mock=false");
  }

  const response = await fetch(`${config.apiBaseUrl}/public/intake/site-widget/messages`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json"
    },
    body: JSON.stringify(request),
    credentials: "omit",
    signal
  });

  let body: unknown = undefined;
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    body = await response.json();
  } else {
    const text = await response.text();
    body = text ? { message: text } : undefined;
  }

  if (!response.ok) {
    const message = readErrorMessage(body) ?? `Widget request failed with HTTP ${response.status}`;
    throw new Error(message);
  }

  return mapSiteWidgetResponse(body, config);
}

export async function mockSiteWidgetMessage(
  config: SiteWidgetConfig,
  request: SiteWidgetMessageRequest
): Promise<SiteWidgetResponseViewModel> {
  await delay(450);

  const text = request.message.text.toLowerCase();
  if (text.includes("менеджер") || text.includes("позвон")) {
    return {
      status: "fallback",
      publicSessionId: request.public_session_id,
      systemText: "Передали менеджеру. Он свяжется с вами по указанным контактам или ответит здесь.",
      reason: "manager_requested",
      raw: { mock: true }
    };
  }

  if (text.includes("сто") || text.includes("цен") || text.includes("расчет") || text.includes("расчёт")) {
    return {
      status: "replied",
      publicSessionId: request.public_session_id,
      replyText:
        "Стоимость зависит от модели, размера и комплектации. Опишите, пожалуйста, какой памятник нужен, или приложите фото — подготовим расчет.",
      raw: { mock: true }
    };
  }

  return {
    status: "replied",
    publicSessionId: request.public_session_id,
    replyText:
      "Приняли сообщение. Уточните, пожалуйста, город, примерный размер и нужен ли монтаж — так менеджер быстрее подготовит ответ.",
    raw: { mock: true }
  };
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function readErrorMessage(body: unknown): string | undefined {
  if (typeof body !== "object" || body === null) return undefined;
  const record = body as Record<string, unknown>;
  if (typeof record.message === "string") return record.message;
  if (typeof record.error === "string") return record.error;
  return undefined;
}
