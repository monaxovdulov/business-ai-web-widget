import type { SiteWidgetConfig, SiteWidgetResponseViewModel } from "../types/public.js";

export function mapSiteWidgetResponse(body: unknown, config: SiteWidgetConfig): SiteWidgetResponseViewModel {
  const record = asRecord(body);
  const automation = asRecord(record?.automation);
  const status = stringValue(automation?.status);
  const publicSessionId =
    stringValue(record?.public_session_id) ??
    stringValue(asRecord(record?.session)?.public_session_id) ??
    stringValue(record?.publicSessionId);

  if (status === "replied") {
    const reply = asRecord(automation?.reply) ?? asRecord(record?.reply);
    const replyText = stringValue(reply?.text) ?? stringValue(reply?.body) ?? stringValue(automation?.text);

    return {
      status: replyText ? "replied" : "fallback",
      publicSessionId,
      replyText: replyText || undefined,
      systemText: replyText ? undefined : config.fallbackMessage,
      reason: stringValue(automation?.reason),
      raw: body
    };
  }

  if (status === "disabled") {
    return {
      status: "disabled",
      publicSessionId,
      systemText:
        stringValue(automation?.message) ??
        stringValue(asRecord(automation?.reply)?.text) ??
        config.disabledMessage,
      reason: stringValue(automation?.reason),
      raw: body
    };
  }

  if (status === "fallback") {
    return {
      status: "fallback",
      publicSessionId,
      systemText:
        stringValue(automation?.message) ??
        stringValue(asRecord(automation?.reply)?.text) ??
        config.fallbackMessage,
      reason: stringValue(automation?.reason),
      raw: body
    };
  }

  return {
    status: "fallback",
    publicSessionId,
    systemText: config.fallbackMessage,
    raw: body
  };
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  if (typeof value === "object" && value !== null && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return undefined;
}

function stringValue(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const trimmed = value.trim();
  return trimmed ? trimmed : undefined;
}
