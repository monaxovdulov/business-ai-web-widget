import { createPublicSessionId } from "./idempotency.js";

const STORAGE_PREFIX = "granit-site-widget:session:";

type StorageLike = Pick<Storage, "getItem" | "setItem" | "removeItem">;

export type SessionStore = {
  get(): string;
  set(publicSessionId: string): void;
  clear(): void;
};

export function createSessionStore(widgetInstanceId: string): SessionStore {
  const key = `${STORAGE_PREFIX}${widgetInstanceId}`;
  const storage = getLocalStorage();
  let memorySessionId: string | undefined;

  return {
    get() {
      const existing = storage?.getItem(key) ?? memorySessionId;
      if (existing && existing.length > 0) return existing;

      const created = createPublicSessionId();
      memorySessionId = created;
      try {
        storage?.setItem(key, created);
      } catch {
        // Storage can be blocked by browser privacy settings. Memory fallback is enough for the tab.
      }
      return created;
    },
    set(publicSessionId: string) {
      if (!publicSessionId) return;
      memorySessionId = publicSessionId;
      try {
        storage?.setItem(key, publicSessionId);
      } catch {
        // Keep memory fallback.
      }
    },
    clear() {
      memorySessionId = undefined;
      try {
        storage?.removeItem(key);
      } catch {
        // Ignore storage errors.
      }
    }
  };
}

function getLocalStorage(): StorageLike | undefined {
  try {
    if (typeof window === "undefined") return undefined;
    return window.localStorage;
  } catch {
    return undefined;
  }
}
