export function createClientMessageId(prefix = "swm"): string {
  return `${prefix}_${randomToken()}`;
}

export function createPublicSessionId(prefix = "sws"): string {
  return `${prefix}_${randomToken()}`;
}

export function createIdempotencyKey(publicSessionId: string): string {
  return `site-widget:${publicSessionId}:${Date.now()}:${randomToken()}`;
}

export function randomToken(): string {
  const cryptoApi = globalThis.crypto;

  if (cryptoApi && typeof cryptoApi.randomUUID === "function") {
    return cryptoApi.randomUUID().replace(/-/g, "");
  }

  const bytes = new Uint8Array(16);
  if (cryptoApi && typeof cryptoApi.getRandomValues === "function") {
    cryptoApi.getRandomValues(bytes);
    return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  return `${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
}
