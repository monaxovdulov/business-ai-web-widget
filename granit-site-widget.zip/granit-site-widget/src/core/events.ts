import type { WidgetEventName } from "../types/public.js";

export function emitWidgetEvent(element: HTMLElement, name: WidgetEventName, detail: unknown = {}): void {
  element.dispatchEvent(
    new CustomEvent(`granit-site-widget:${name}`, {
      bubbles: true,
      composed: true,
      detail
    })
  );
}
