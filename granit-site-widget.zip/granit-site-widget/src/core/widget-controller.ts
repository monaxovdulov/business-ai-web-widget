import type { WidgetMessage } from "../types/public.js";
import { createClientMessageId } from "./idempotency.js";

export type PendingWidgetRequest = {
  text: string;
  idempotencyKey: string;
};

export type WidgetControllerSnapshot = {
  open: boolean;
  submitting: boolean;
  draft: string;
  contactPhone: string;
  contactCaptureOpen: boolean;
  messages: WidgetMessage[];
  pending?: PendingWidgetRequest;
};

export class WidgetController {
  private state: WidgetControllerSnapshot;

  constructor(introMessage: string, initialOpen = false) {
    this.state = {
      open: initialOpen,
      submitting: false,
      draft: "",
      contactPhone: "",
      contactCaptureOpen: false,
      messages: [this.createMessage("assistant", introMessage)],
      pending: undefined
    };
  }

  snapshot(): WidgetControllerSnapshot {
    return {
      ...this.state,
      messages: [...this.state.messages]
    };
  }

  open(): void {
    this.state.open = true;
  }

  close(): void {
    this.state.open = false;
  }

  setDraft(value: string): void {
    this.state.draft = value;
  }

  clearDraft(): void {
    this.state.draft = "";
  }

  setContactPhone(value: string): void {
    this.state.contactPhone = value.trim();
  }

  toggleContactCapture(open?: boolean): void {
    this.state.contactCaptureOpen = typeof open === "boolean" ? open : !this.state.contactCaptureOpen;
  }

  beginSubmit(text: string, idempotencyKey: string): void {
    this.state.submitting = true;
    this.state.pending = { text, idempotencyKey };
    this.state.messages = this.state.messages.map((message) => ({
      ...message,
      status: message.status === "error" ? "sent" : message.status
    }));
    this.state.messages.push(this.createMessage("visitor", text, "pending"));
    this.clearDraft();
  }

  beginRetry(): void {
    if (!this.state.pending) return;
    this.state.submitting = true;
    this.state.messages = this.state.messages.filter((message) => message.status !== "error");
    this.state.messages = this.state.messages.map((message) => ({
      ...message,
      status: message.role === "visitor" && message.text === this.state.pending?.text ? "pending" : message.status
    }));
  }

  markVisitorSent(text: string): void {
    this.state.messages = this.state.messages.map((message) =>
      message.role === "visitor" && message.text === text && message.status === "pending"
        ? { ...message, status: "sent" }
        : message
    );
  }

  finishWithAssistant(text: string): void {
    if (text.trim()) {
      this.state.messages.push(this.createMessage("assistant", text, "sent", true));
    }
    this.finishSubmit();
  }

  finishWithSystem(text: string): void {
    if (text.trim()) {
      this.state.messages.push(this.createMessage("system", text));
    }
    this.finishSubmit();
  }

  fail(text: string): void {
    this.state.submitting = false;
    this.state.messages = this.state.messages.map((message) =>
      message.role === "visitor" && message.status === "pending" ? { ...message, status: "error" } : message
    );
    this.state.messages.push(this.createMessage("system", text, "error"));
  }

  private finishSubmit(): void {
    this.state.submitting = false;
    this.state.pending = undefined;
  }

  private createMessage(
    role: WidgetMessage["role"],
    text: string,
    status: WidgetMessage["status"] = "sent",
    disclosure = false
  ): WidgetMessage {
    return {
      id: createClientMessageId("msg"),
      role,
      text,
      createdAt: new Date().toISOString(),
      status,
      disclosure
    };
  }
}
