export const DESIGN_TOKENS = {
  colorAccent: "#9d8062",
  colorAccentText: "#ffffff",
  colorSurfacePanel: "#fbf8f4",
  colorSurfaceRaised: "#ffffff",
  colorSurfaceVisitor: "#efe2d5",
  colorSurfaceSystem: "#f5efe8",
  colorTextPrimary: "#29241f",
  colorTextSecondary: "#746c64",
  colorBorder: "rgba(52, 44, 36, 0.12)",
  colorSuccess: "#5ebc55",
  radiusPanel: "28px",
  radiusBubble: "16px",
  radiusButton: "999px",
  shadowPanel: "0 28px 90px rgba(35, 29, 22, 0.18)",
  shadowLauncher: "0 14px 38px rgba(81, 62, 45, 0.25)",
  fontFamily: "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
} as const;
