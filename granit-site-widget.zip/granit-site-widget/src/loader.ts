void (async () => {
  const script = document.currentScript as HTMLScriptElement | null;
  if (!script) return;

  const sourceUrl = script.src || window.location.href;
  const baseUrl = sourceUrl.slice(0, sourceUrl.lastIndexOf("/") + 1);
  const moduleUrl = new URL("./site-widget.esm.js", baseUrl).toString();
  const module = await import(moduleUrl);

  module.defineSiteWidget();

  const existingSelector = script.dataset.targetSelector;
  if (existingSelector) {
    const targetElement = document.querySelector(existingSelector);
    if (targetElement) {
      module.mountSiteWidget({ target: targetElement, ...datasetToOptions(script.dataset) });
      return;
    }
  }

  module.mountSiteWidget(datasetToOptions(script.dataset));
})();

function datasetToOptions(dataset: DOMStringMap): Record<string, unknown> {
  const options: Record<string, unknown> = {};
  const map: Record<string, string> = {
    apiBaseUrl: "apiBaseUrl",
    widgetInstanceId: "widgetInstanceId",
    theme: "theme",
    position: "position",
    launcherLabel: "launcherLabel",
    headerTitle: "headerTitle",
    headerStatus: "headerStatus",
    headerResponseTime: "headerResponseTime",
    introMessage: "introMessage",
    placeholder: "placeholder",
    phoneHref: "phoneHref",
    privacyUrl: "privacyUrl",
    fallbackMessage: "fallbackMessage",
    disabledMessage: "disabledMessage",
    errorMessage: "errorMessage"
  };

  for (const [datasetKey, optionKey] of Object.entries(map)) {
    const value = dataset[datasetKey];
    if (typeof value === "string" && value.length > 0) options[optionKey] = value;
  }

  if (dataset.mock === "true" || dataset.mock === "1") options.mock = true;
  if (dataset.quickReplies) options.quickReplies = parseConfigList(dataset.quickReplies);
  if (dataset.mobileActions) options.mobileActions = parseConfigList(dataset.mobileActions);

  return options;
}

function parseConfigList(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return value
      .split("|")
      .map((item) => item.trim())
      .filter(Boolean)
      .map((label) => ({ label, value: label }));
  }
}
