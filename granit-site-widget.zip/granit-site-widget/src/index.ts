import { applyOptionsToElement } from "./config/config-schema.js";
import { GranitSiteWidgetElement, SITE_WIDGET_TAG_NAME } from "./component/site-widget-element.js";
import type { MountSiteWidgetOptions } from "./types/public.js";

export { GranitSiteWidgetElement, SITE_WIDGET_TAG_NAME };
export type * from "./types/public.js";

export function defineSiteWidget(tagName = SITE_WIDGET_TAG_NAME): void {
  if (typeof window === "undefined" || !window.customElements) return;
  if (!window.customElements.get(tagName)) {
    window.customElements.define(tagName, GranitSiteWidgetElement);
  }
}

export function mountSiteWidget(options: MountSiteWidgetOptions = {}): GranitSiteWidgetElement {
  if (typeof document === "undefined") {
    throw new Error("mountSiteWidget requires a browser document");
  }

  defineSiteWidget();

  const element = document.createElement(SITE_WIDGET_TAG_NAME) as GranitSiteWidgetElement;
  applyOptionsToElement(element, options);

  const target = options.target ?? document.body;
  if (!target) throw new Error("mountSiteWidget target was not found");
  target.appendChild(element);
  return element;
}

declare global {
  interface Window {
    GranitSiteWidget?: {
      define: typeof defineSiteWidget;
      mount: typeof mountSiteWidget;
      tagName: string;
    };
  }
}

if (typeof window !== "undefined") {
  window.GranitSiteWidget = {
    define: defineSiteWidget,
    mount: mountSiteWidget,
    tagName: SITE_WIDGET_TAG_NAME
  };
  defineSiteWidget();
}
