# Checks Run

```bash
npm run build
npm test
node --check dist/loader.js
node --check dist/component/site-widget-element.js
node -e "import('./dist/site-widget.esm.js').then(m=>console.log(Object.keys(m).sort().join(',')))"
```

Result: passed in the generated artifact environment.
