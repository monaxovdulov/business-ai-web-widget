import assert from "node:assert/strict";
import { buildSiteWidgetMessageRequest, parseUtm } from "../dist/core/site-widget-request.js";

const config = {
  apiBaseUrl: "https://ops.example.test",
  widgetInstanceId: "memorial-main",
  theme: "memorial-soft",
  position: "bottom-right",
  mock: false,
  launcherLabel: "Написать",
  headerTitle: "Поможем с заказом",
  headerStatus: "Онлайн",
  headerResponseTime: "обычно отвечаем за 2 минуты",
  introMessage: "Здравствуйте",
  placeholder: "Напишите сообщение...",
  disclosureText: "Ответ подготовлен автоматически.",
  footerNote: "Расчет бесплатный.",
  phoneCaptureLabel: "Добавить телефон",
  phoneSavedLabel: "Телефон добавлен",
  fallbackMessage: "Менеджер ответит.",
  disabledMessage: "Менеджер проверит.",
  errorMessage: "Ошибка.",
  retryLabel: "Повторить",
  sendLabel: "Отправить",
  attachLabel: "Приложить файл",
  closeLabel: "Закрыть",
  minimizeLabel: "Свернуть",
  quickReplies: [],
  mobileActions: []
};

const request = buildSiteWidgetMessageRequest({
  config,
  text: "Сколько стоит памятник?",
  publicSessionId: "sws_test",
  idempotencyKey: "idem_1",
  contact: { phone: "+79990000000", preferred_contact: "phone" }
});

assert.equal(request.schema_version, "site_widget.v1");
assert.equal(request.event_type, "site_widget.message_submitted");
assert.equal(request.idempotency_key, "idem_1");
assert.equal(request.public_session_id, "sws_test");
assert.equal(request.source.channel, "site_widget");
assert.equal(request.source.widget_instance_id, "memorial-main");
assert.equal(request.message.role, "visitor");
assert.equal(request.message.text, "Сколько стоит памятник?");
assert.equal(request.contact.phone, "+79990000000");
assert.equal(request.contact.preferred_contact, "phone");

assert.deepEqual(parseUtm("?utm_source=yandex&utm_medium=cpc&utm_campaign=summer"), {
  source: "yandex",
  medium: "cpc",
  campaign: "summer"
});

console.log("request-builder.test.mjs passed");
