# Granit Site Widget

Framework-agnostic public website widget implemented as a Web Component.

The package contains:

- `dist/loader.js` — script-tag loader for landing pages;
- `dist/site-widget.esm.js` — ESM entry for direct Web Component usage;
- `src/` — TypeScript source split by the selected architecture;
- `design.md` — portable design contract and token names;
- `ARCHITECTURE.md` — architecture decision and integration boundary;
- `examples/` — plain HTML demos.

## 1. Fast integration

Use this on a regular landing page:

```html
<script
  async
  src="https://cdn.example.com/site-widget/v1/loader.js"
  data-widget-instance-id="memorial-main"
  data-api-base-url="https://ops.example.com"
  data-theme="memorial-soft">
</script>
```

For local demo without a backend:

```html
<script
  async
  src="../dist/loader.js"
  data-mock="true"
  data-widget-instance-id="memorial-main">
</script>
```

The loader creates:

```html
<granit-site-widget></granit-site-widget>
```

and mounts it into `document.body`.

## 2. Direct Web Component integration

```html
<script type="module" src="https://cdn.example.com/site-widget/v1/site-widget.esm.js"></script>

<granit-site-widget
  widget-instance-id="memorial-main"
  api-base-url="https://ops.example.com"
  theme="memorial-soft">
</granit-site-widget>
```

The same element works inside React, Vue, Svelte, Astro, Next, Nuxt, WordPress, Tilda custom HTML blocks, and static HTML.

## 3. Programmatic integration

```ts
import { defineSiteWidget, mountSiteWidget } from "@granit/site-widget";

defineSiteWidget();

const widget = mountSiteWidget({
  widgetInstanceId: "memorial-main",
  apiBaseUrl: "https://ops.example.com",
  theme: "memorial-soft"
});

widget.open();
widget.sendMessage("Сколько стоит памятник с установкой?");
```

## 4. Runtime API request

On submit the widget sends:

```http
POST /public/intake/site-widget/messages
Content-Type: application/json
```

Request shape:

```json
{
  "schema_version": "site_widget.v1",
  "event_type": "site_widget.message_submitted",
  "idempotency_key": "site-widget:sws_...",
  "submitted_at": "2026-06-16T12:00:00.000Z",
  "public_session_id": "sws_...",
  "source": {
    "channel": "site_widget",
    "page_url": "https://example.com/page",
    "widget_instance_id": "memorial-main",
    "page_title": "Landing title",
    "referrer_url": "https://referrer.example"
  },
  "contact": {
    "phone": "+79990000000",
    "preferred_contact": "phone"
  },
  "message": {
    "role": "visitor",
    "text": "Сколько стоит памятник с установкой?"
  },
  "visitor_context": {
    "locale": "ru-RU",
    "timezone": "Europe/Moscow"
  }
}
```

The browser renders AI text only when backend response contains:

```json
{
  "automation": {
    "status": "replied",
    "reply": {
      "text": "..."
    }
  }
}
```

For `fallback` or `disabled`, the widget shows a manager-review system message.

## 5. Attributes

| Attribute | Type | Default | Purpose |
|---|---:|---|---|
| `api-base-url` | string | `""` | Backend base URL without trailing slash. |
| `widget-instance-id` | string | `default` | Public widget instance key. |
| `theme` | string | `memorial-soft` | Named theme switch. |
| `position` | string | `bottom-right` | `bottom-right`, `bottom-left`, or `inline`. |
| `mock` | boolean | `false` | Local demo mode; no HTTP request. |
| `launcher-label` | string | `Написать` | Closed-state button label. |
| `header-title` | string | `Поможем с заказом` | Panel title. |
| `header-status` | string | `Онлайн` | Header status text. |
| `header-response-time` | string | `обычно отвечаем за 2 минуты` | Header subtext. |
| `intro-message` | string | built-in | First assistant message. |
| `placeholder` | string | `Напишите сообщение...` | Composer placeholder. |
| `phone-href` | string | — | `tel:` link for mobile call action. |
| `quick-replies` | JSON or `|` list | built-in | Quick reply buttons. |

## 6. CSS customization

The component uses Shadow DOM. Host pages customize it through CSS variables and exposed `::part()` names.

```css
granit-site-widget {
  --sw-color-accent: #9d8062;
  --sw-color-surface-panel: #fffaf3;
  --sw-color-surface-message-visitor: #efe2d5;
  --sw-color-text-primary: #27231f;
  --sw-radius-panel: 28px;
  --sw-shadow-panel: 0 28px 90px rgba(35, 29, 22, 0.18);
  --sw-font-family: Inter, system-ui, sans-serif;
}

granit-site-widget::part(launcher) {
  letter-spacing: 0.01em;
}

granit-site-widget::part(panel) {
  backdrop-filter: blur(10px);
}
```

See `design.md` for the full token and part contract.

## 7. Events

All events bubble and cross the Shadow DOM boundary.

```ts
document.addEventListener("granit-site-widget:message-submitted", (event) => {
  console.log(event.detail);
});
```

| Event | When emitted |
|---|---|
| `granit-site-widget:ready` | Component is mounted and initialized. |
| `granit-site-widget:open` | Panel opens. |
| `granit-site-widget:close` | Panel closes. |
| `granit-site-widget:message-submitted` | Client-side request is built and submission starts. |
| `granit-site-widget:response` | Backend or mock response is mapped to UI. |
| `granit-site-widget:error` | Network or validation failure. |
| `granit-site-widget:phone-saved` | Visitor saved phone locally before submit. |

## 8. Security and boundary rules

- The widget renders response text as plain text. It does not inject backend HTML.
- The widget stores only `public_session_id` in `localStorage`.
- It sends a client-generated `idempotency_key` on every submit.
- It never uses internal `leadId`, `conversationId`, provider data, model names, or AI credentials.
- AI provider calls stay behind the backend public intake boundary.
- CORS must allow the production landing origins on the backend.

## 9. Local development

```bash
npm install
npm run build
npm test
npx http-server . -p 4173
```

Open:

```text
http://localhost:4173/examples/plain-html.html
```

## 10. Files to publish

For CDN/script usage, publish the complete `dist/` directory because `loader.js` dynamically imports `site-widget.esm.js`, which imports the compiled component modules.

Recommended CDN path:

```text
/site-widget/v1/dist/*
```

Then use:

```html
<script async src="https://cdn.example.com/site-widget/v1/dist/loader.js" ...></script>
```
